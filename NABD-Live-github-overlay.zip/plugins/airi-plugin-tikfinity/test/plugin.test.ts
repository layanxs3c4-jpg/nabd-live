import type { ClientOptions } from '@proj-airi/server-sdk'

import type { TikFinityTransport, TikFinityTransportHandlers } from '../src/bridge'

import { describe, expect, it, vi } from 'vitest'

import { TikFinityAiriPlugin } from '../src/plugin'

class FakeTransport implements TikFinityTransport {
  handlers?: TikFinityTransportHandlers

  connect(handlers: TikFinityTransportHandlers): void {
    this.handlers = handlers
  }

  send(): void {}
  close(): void {}
}

describe('TikFinityAiriPlugin', () => {
  it('forwards a real TikFinity comment to the AIRI input channel', async () => {
    const transport = new FakeTransport()
    const connect = vi.fn(async () => {})
    const sendOrThrow = vi.fn()
    const plugin = new TikFinityAiriPlugin({
      tikFinityEndpoint: 'ws://localhost:21213',
      createTikFinityTransport: () => transport,
      createAiriClient: (_options: ClientOptions) => ({ connect, sendOrThrow, close: vi.fn() }),
    })

    await plugin.start()
    transport.handlers?.open()
    transport.handlers?.message(JSON.stringify({
      event: 'comment',
      data: { uniqueId: 'sara', nickname: 'Sara', comment: 'Hello AIRI' },
    }))

    expect(connect).toHaveBeenCalledOnce()
    expect(sendOrThrow).toHaveBeenCalledWith({
      type: 'input:text',
      data: { text: '[TikTok LIVE comment] Sara (@sara): Hello AIRI' },
    })
    expect(plugin.tikFinitySnapshot.status).toBe('verified')
  })

  it('does not forward likes by default', async () => {
    const transport = new FakeTransport()
    const sendOrThrow = vi.fn()
    const plugin = new TikFinityAiriPlugin({
      tikFinityEndpoint: 'ws://localhost:21213',
      createTikFinityTransport: () => transport,
      createAiriClient: () => ({ connect: async () => {}, sendOrThrow, close: vi.fn() }),
    })

    await plugin.start()
    transport.handlers?.open()
    transport.handlers?.message(JSON.stringify({
      event: 'like',
      data: { nickname: 'Ali', likeCount: 10 },
    }))

    expect(sendOrThrow).not.toHaveBeenCalled()
    expect(plugin.tikFinitySnapshot.status).toBe('verified')
  })

  it('answers a points command with one AIRI input', async () => {
    const transport = new FakeTransport()
    const sendOrThrow = vi.fn()
    const plugin = new TikFinityAiriPlugin({
      tikFinityEndpoint: 'ws://localhost:21213',
      createTikFinityTransport: () => transport,
      createAiriClient: () => ({ connect: async () => {}, sendOrThrow, close: vi.fn() }),
    })

    await plugin.start()
    transport.handlers?.open()
    transport.handlers?.message(JSON.stringify({
      event: 'comment',
      data: { userId: '1', nickname: 'Sara', comment: '!نقاط' },
    }))

    expect(sendOrThrow).toHaveBeenCalledOnce()
    expect(sendOrThrow.mock.calls[0]?.[0].data.text).toContain('Sara has 1 points')
  })

  it('asks AIRI to announce a live quiz', async () => {
    const transport = new FakeTransport()
    const sendOrThrow = vi.fn()
    const plugin = new TikFinityAiriPlugin({
      tikFinityEndpoint: 'ws://localhost:21213',
      createTikFinityTransport: () => transport,
      createAiriClient: () => ({ connect: async () => {}, sendOrThrow, close: vi.fn() }),
    })

    await plugin.start()
    plugin.startQuiz('ما عاصمة السعودية؟', ['الرياض'], 50)

    expect(sendOrThrow).toHaveBeenCalledWith({
      type: 'input:text',
      data: { text: expect.stringContaining('ما عاصمة السعودية؟') },
    })
  })

  it('counts poll votes and announces the result', async () => {
    const transport = new FakeTransport()
    const sendOrThrow = vi.fn()
    const plugin = new TikFinityAiriPlugin({
      tikFinityEndpoint: 'ws://localhost:21213',
      createTikFinityTransport: () => transport,
      createAiriClient: () => ({ connect: async () => {}, sendOrThrow, close: vi.fn() }),
    })

    await plugin.start()
    plugin.startPoll('اختر اللون', ['أحمر', 'أزرق'])
    transport.handlers?.message(JSON.stringify({
      event: 'comment',
      data: { userId: '1', nickname: 'Sara', comment: '2' },
    }))
    plugin.stopPoll()

    expect(sendOrThrow).toHaveBeenCalledTimes(2)
    expect(sendOrThrow.mock.calls[1]?.[0].data.text).toContain('أزرق: 1')
  })
})
