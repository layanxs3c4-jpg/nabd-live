import type { TikFinityTransport, TikFinityTransportHandlers } from '../src/bridge'

import { describe, expect, it, vi } from 'vitest'

import { TikFinityBridge } from '../src/bridge'

class FakeTransport implements TikFinityTransport {
  handlers?: TikFinityTransportHandlers
  sent: string[] = []
  closed = false

  connect(handlers: TikFinityTransportHandlers): void {
    this.handlers = handlers
  }

  send(message: string): void {
    this.sent.push(message)
  }

  close(): void {
    this.closed = true
  }
}

describe('TikFinityBridge', () => {
  it('does not report a verified connection before a real event', () => {
    const transport = new FakeTransport()
    const snapshots: string[] = []
    const bridge = new TikFinityBridge({
      endpoint: 'ws://localhost:21213',
      createTransport: () => transport,
      onEvent: vi.fn(),
      onSnapshot: snapshot => snapshots.push(snapshot.status),
    })

    bridge.start()
    transport.handlers?.open()

    expect(bridge.snapshot.status).toBe('socket-open')
    expect(bridge.snapshot.eventCount).toBe(0)
    expect(snapshots).not.toContain('verified')
  })

  it('reports a verified connection after it decodes a comment', () => {
    const transport = new FakeTransport()
    const onEvent = vi.fn()
    const bridge = new TikFinityBridge({
      endpoint: 'ws://localhost:21213',
      createTransport: () => transport,
      onEvent,
    })

    bridge.start()
    transport.handlers?.open()
    transport.handlers?.message(JSON.stringify({
      event: 'chat',
      data: { userId: '1', nickname: 'Sara', comment: 'Hello' },
    }))

    expect(bridge.snapshot.status).toBe('verified')
    expect(bridge.snapshot.rawMessageCount).toBe(1)
    expect(bridge.snapshot.eventCount).toBe(1)
    expect(bridge.snapshot.sessionEventCount).toBe(1)
    expect(onEvent).toHaveBeenCalledOnce()
  })

  it('records unknown frames without reporting a verified connection', () => {
    const transport = new FakeTransport()
    const onRecord = vi.fn()
    const bridge = new TikFinityBridge({
      endpoint: 'ws://localhost:21213',
      createTransport: () => transport,
      onEvent: vi.fn(),
      onRecord,
      now: () => 5_000,
    })

    bridge.start()
    transport.handlers?.open()
    transport.handlers?.message('{"event":"roomInfo","data":{"viewerCount":10}}')

    expect(bridge.snapshot.status).toBe('socket-open')
    expect(bridge.snapshot.unknownMessageCount).toBe(1)
    expect(onRecord).toHaveBeenCalledWith({
      raw: '{"event":"roomInfo","data":{"viewerCount":10}}',
      recordedAt: 5_000,
    })
  })

  it('replies to a Socket.IO heartbeat without reporting an event', () => {
    const transport = new FakeTransport()
    const bridge = new TikFinityBridge({
      endpoint: 'ws://localhost:21213',
      createTransport: () => transport,
      onEvent: vi.fn(),
    })

    bridge.start()
    transport.handlers?.open()
    transport.handlers?.message('2')

    expect(transport.sent).toEqual(['3'])
    expect(bridge.snapshot.status).toBe('socket-open')
    expect(bridge.snapshot.eventCount).toBe(0)
  })

  it('does not mark an intermediate gift streak as unknown', () => {
    const transport = new FakeTransport()
    const bridge = new TikFinityBridge({
      endpoint: 'ws://localhost:21213',
      createTransport: () => transport,
      onEvent: vi.fn(),
    })

    bridge.start()
    transport.handlers?.open()
    transport.handlers?.message('42["gift",{"giftType":1,"repeatEnd":false,"repeatCount":2,"giftName":"Rose"}]')

    expect(bridge.snapshot.unknownMessageCount).toBe(0)
    expect(bridge.snapshot.eventCount).toBe(0)
  })

  it('ignores duplicate events inside the deduplication window', () => {
    const transport = new FakeTransport()
    const onEvent = vi.fn()
    const bridge = new TikFinityBridge({
      endpoint: 'ws://localhost:21213',
      createTransport: () => transport,
      onEvent,
      now: () => 10_000,
    })
    const comment = JSON.stringify({
      event: 'comment',
      data: { messageId: 'message-1', nickname: 'Sara', comment: 'Hello' },
    })

    bridge.start()
    transport.handlers?.open()
    transport.handlers?.message(comment)
    transport.handlers?.message(comment)

    expect(onEvent).toHaveBeenCalledOnce()
    expect(bridge.snapshot.rawMessageCount).toBe(2)
    expect(bridge.snapshot.eventCount).toBe(1)
  })

  it('ignores callbacks from a stale transport after reconnect', () => {
    const transports = [new FakeTransport(), new FakeTransport()]
    let reconnect: (() => void) | undefined
    const bridge = new TikFinityBridge({
      endpoint: 'ws://localhost:21213',
      createTransport: () => transports.shift()!,
      onEvent: vi.fn(),
      schedule: callback => {
        reconnect = callback
        return () => {
          reconnect = undefined
        }
      },
    })

    const firstTransport = transports[0]!
    const secondTransport = transports[1]!
    bridge.start()
    firstTransport.handlers?.open()
    firstTransport.handlers?.close()
    reconnect?.()
    secondTransport.handlers?.open()
    firstTransport.handlers?.message(JSON.stringify({ event: 'comment', data: { comment: 'stale' } }))
    firstTransport.handlers?.close()

    expect(bridge.snapshot.status).toBe('socket-open')
    expect(bridge.snapshot.rawMessageCount).toBe(0)
  })
})
