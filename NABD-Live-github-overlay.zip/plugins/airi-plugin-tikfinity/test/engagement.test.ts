import type { TikFinityEvent } from '../src/types'

import { describe, expect, it, vi } from 'vitest'

import { TikFinityEngagementEngine } from '../src/engagement'

function comment(text: string, id = '1', displayName = 'Sara'): TikFinityEvent {
  return {
    type: 'comment',
    eventId: `comment-${text}-${id}`,
    rawType: 'comment',
    receivedAt: 1_000,
    source: 'tikfinity',
    user: { id, displayName },
    text,
  }
}

describe('TikFinityEngagementEngine', () => {
  it('adds points for comments and gifts', () => {
    const engine = new TikFinityEngagementEngine()
    engine.handleEvent(comment('Hello'))
    engine.handleEvent({
      type: 'gift',
      rawType: 'gift',
      receivedAt: 2_000,
      source: 'tikfinity',
      user: { id: '1', displayName: 'Sara' },
      giftName: 'Rose',
      coins: 1,
      repeatCount: 3,
    })

    expect(engine.snapshot.scores[0]).toMatchObject({ userId: '1', points: 4 })
  })

  it('answers the Arabic points command without forwarding it as chat', () => {
    const engine = new TikFinityEngagementEngine()
    const result = engine.handleEvent(comment('!نقاط'))

    expect(result.suppressDefault).toBe(true)
    expect(result.messages[0]).toContain('Sara has 1 points')
  })

  it('accepts an Arabic answer without diacritics and rewards the first winner', () => {
    const onSnapshot = vi.fn()
    const engine = new TikFinityEngagementEngine({ onSnapshot, now: () => 4_000 })
    const prompt = engine.startQuiz('ما عاصمة السعودية؟', ['الرِّياض'], 50)
    const result = engine.handleEvent(comment('الرياض'))

    expect(prompt).toContain('50 points')
    expect(result.suppressDefault).toBe(true)
    expect(result.messages[0]).toContain('quiz winner')
    expect(engine.snapshot.quiz).toBeUndefined()
    expect(engine.snapshot.winner).toMatchObject({ displayName: 'Sara', points: 51 })
    expect(onSnapshot).toHaveBeenCalled()
  })

  it('keeps the first correct answer as the only quiz winner', () => {
    const engine = new TikFinityEngagementEngine({ now: () => 4_000 })
    engine.startQuiz('ما عاصمة السعودية؟', ['الرياض'], 50)

    const first = engine.handleEvent(comment('الرياض', '1', 'Sara'))
    const second = engine.handleEvent(comment('الرياض', '2', 'Ali'))

    expect(first.messages[0]).toContain('quiz winner')
    expect(second.messages).toEqual([])
    expect(engine.snapshot.winner).toMatchObject({ userId: '1', displayName: 'Sara' })
    expect(engine.snapshot.scores.find(score => score.userId === '1')?.points).toBe(51)
    expect(engine.snapshot.scores.find(score => score.userId === '2')?.points).toBe(1)
  })

  it('reads the top five viewers through the leaderboard command', () => {
    const engine = new TikFinityEngagementEngine({
      initialScores: [
        { userId: '1', displayName: 'Sara', points: 10 },
        { userId: '2', displayName: 'Ali', points: 20 },
      ],
    })
    const result = engine.handleEvent(comment('!ترتيب', '3', 'Reem'))

    expect(result.suppressDefault).toBe(true)
    expect(result.messages[0]).toContain('1. Ali: 20')
    expect(result.messages[0]).toContain('2. Sara: 10')
  })

  it('counts one audience poll vote per viewer', () => {
    const engine = new TikFinityEngagementEngine()
    engine.startPoll('اختر اللون', ['أحمر', 'أزرق'])

    expect(engine.handleEvent(comment('2')).suppressDefault).toBe(true)
    engine.handleEvent(comment('أحمر'))
    engine.handleEvent(comment('أحمر', '2', 'Ali'))
    const result = engine.stopPoll()

    expect(result).toContain('أحمر: 1')
    expect(result).toContain('أزرق: 1')
    expect(engine.snapshot.pollResult?.winnerLabels).toEqual(['أحمر', 'أزرق'])
  })
})
