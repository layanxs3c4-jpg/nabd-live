import { describe, expect, it } from 'vitest'

import { decodeTikFinityMessage, decodeTikFinityRecord } from '../src/decode'
import { formatTikFinityEvent } from '../src/format'

describe('decodeTikFinityMessage', () => {
  it('decodes a nested comment envelope', () => {
    // ROOT CAUSE:
    //
    // A nested `data` object can recurse forever when the merged envelope keeps
    // the original `data` property. The decoder removes it before recursion.
    const result = decodeTikFinityMessage(JSON.stringify({
      event: 'chat',
      data: {
        userId: '42',
        uniqueId: 'lina_live',
        nickname: 'Lina',
        comment: 'Hello AIRI',
      },
    }), 1_000)

    expect(result.parsed).toBe(true)
    expect(result.recognized).toBe(true)
    expect(result.events).toEqual([{
      type: 'comment',
      eventId: undefined,
      rawType: 'chat',
      receivedAt: 1_000,
      source: 'tikfinity',
      user: {
        id: '42',
        username: 'lina_live',
        displayName: 'Lina',
        avatarUrl: undefined,
      },
      text: 'Hello AIRI',
    }])
  })

  it('decodes a Socket.IO gift frame after the gift streak ends', () => {
    const result = decodeTikFinityMessage('42["gift",{"userId":"7","nickname":"Khalid","giftName":"Rose","giftId":5655,"coins":1,"repeatCount":3,"repeatEnd":true}]', 2_000)

    expect(result.events).toHaveLength(1)
    expect(result.events[0]).toMatchObject({
      type: 'gift',
      giftName: 'Rose',
      giftId: '5655',
      coins: 1,
      repeatCount: 3,
    })
  })

  it('does not emit an intermediate gift streak frame', () => {
    const result = decodeTikFinityMessage('42["gift",{"giftType":1,"repeatEnd":false,"repeatCount":2,"giftName":"Rose"}]')

    expect(result.events).toEqual([])
  })

  it('returns the Socket.IO heartbeat reply', () => {
    expect(decodeTikFinityMessage('2')).toEqual({
      parsed: true,
      recognized: true,
      events: [],
      heartbeatReply: '3',
    })
  })

  it('marks invalid JSON as unparsed', () => {
    expect(decodeTikFinityMessage('not-json')).toEqual({
      parsed: false,
      recognized: false,
      events: [],
    })
  })

  it('replays a record with its original time', () => {
    const result = decodeTikFinityRecord({
      raw: JSON.stringify({ event: 'follow', data: { nickname: 'Sara' } }),
      recordedAt: 4_000,
    })

    expect(result.events[0]).toMatchObject({
      type: 'follow',
      receivedAt: 4_000,
    })
  })

  it('formats a normalized comment for the AIRI input channel', () => {
    const result = decodeTikFinityMessage(JSON.stringify({
      event: 'comment',
      data: { uniqueId: 'reem', nickname: 'Reem', comment: 'How are you?' },
    }))

    expect(formatTikFinityEvent(result.events[0]!)).toBe('[TikTok LIVE comment] Reem (@reem): How are you?')
  })
})
