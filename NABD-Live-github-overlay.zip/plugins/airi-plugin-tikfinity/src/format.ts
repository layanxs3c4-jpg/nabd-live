import type { TikFinityEvent } from './types'

function userLabel(event: TikFinityEvent): string {
  if (event.user.username && event.user.username !== event.user.displayName) {
    return `${event.user.displayName} (@${event.user.username.replace(/^@/, '')})`
  }
  return event.user.displayName
}

/**
 * Formats a TikFinity event as an AIRI text input.
 *
 * @example
 * formatTikFinityEvent(commentEvent)
 * // => '[TikTok LIVE comment] Lina: Hello'
 */
export function formatTikFinityEvent(event: TikFinityEvent): string {
  const user = userLabel(event)
  switch (event.type) {
    case 'comment':
      return `[TikTok LIVE comment] ${user}: ${event.text}`
    case 'gift':
      return `[TikTok LIVE gift] ${user} sent ${event.giftName} x${event.repeatCount} (${event.coins} coins).`
    case 'follow':
      return `[TikTok LIVE follow] ${user} followed the account.`
    case 'subscribe':
      return event.months
        ? `[TikTok LIVE subscription] ${user} subscribed for ${event.months} months.`
        : `[TikTok LIVE subscription] ${user} subscribed.`
    case 'share':
      return `[TikTok LIVE share] ${user} shared the live stream.`
    case 'like':
      return `[TikTok LIVE likes] ${user} sent ${event.likeCount} likes.`
  }
}
