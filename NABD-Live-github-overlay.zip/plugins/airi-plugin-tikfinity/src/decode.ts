import type {
  TikFinityDecodeResult,
  TikFinityEvent,
  TikFinityRecord,
  TikFinityUser,
} from './types'

type UnknownRecord = Record<string, unknown>

const userIdKeys = ['userId', 'userID', 'uniqueId', 'uniqueID', 'username'] as const
const userNameKeys = ['nickname', 'nickName', 'displayName', 'uniqueId', 'username'] as const

function isRecord(value: unknown): value is UnknownRecord {
  return typeof value === 'object' && value !== null && !Array.isArray(value)
}

function firstValue(record: UnknownRecord, keys: readonly string[]): unknown {
  for (const key of keys) {
    const value = record[key]
    if (value !== undefined && value !== null && value !== '') {
      return value
    }
  }
}

function readText(record: UnknownRecord, keys: readonly string[]): string | undefined {
  const value = firstValue(record, keys)
  if (typeof value === 'string' || typeof value === 'number') {
    const text = String(value).trim()
    return text || undefined
  }
}

function readNumber(record: UnknownRecord, keys: readonly string[]): number | undefined {
  const value = firstValue(record, keys)
  if (typeof value !== 'number' && typeof value !== 'string') {
    return
  }

  const number = Number(value)
  if (Number.isFinite(number)) {
    return number
  }
}

function readBoolean(record: UnknownRecord, keys: readonly string[]): boolean | undefined {
  const value = firstValue(record, keys)
  if (typeof value === 'boolean') {
    return value
  }
  if (value === 'true' || value === 1 || value === '1') {
    return true
  }
  if (value === 'false' || value === 0 || value === '0') {
    return false
  }
}

function readUser(payload: UnknownRecord): TikFinityUser {
  const nestedUser = firstValue(payload, ['user', 'userDetails', 'userInfo'])
  const user = isRecord(nestedUser) ? nestedUser : {}
  const id = readText(payload, userIdKeys) ?? readText(user, userIdKeys) ?? 'guest'
  const displayName = readText(payload, userNameKeys) ?? readText(user, userNameKeys) ?? 'TikTok viewer'

  return {
    id,
    username: readText(payload, ['uniqueId', 'username']) ?? readText(user, ['uniqueId', 'username']),
    displayName,
    avatarUrl: readText(payload, ['profilePictureUrl', 'profilePicturUrl', 'avatarUrl'])
      ?? readText(user, ['profilePictureUrl', 'profilePicturUrl', 'avatarUrl']),
  }
}

function readRawType(payload: UnknownRecord, inheritedType: string): string {
  return readText(payload, ['event', 'eventType', 'type', 'action']) ?? inheritedType
}

function flattenPayloads(value: unknown, inheritedType = ''): UnknownRecord[] {
  if (Array.isArray(value)) {
    if (typeof value[0] === 'string' && isRecord(value[1])) {
      return flattenPayloads({ ...value[1], event: value[0] }, value[0])
    }
    return value.flatMap(item => flattenPayloads(item, inheritedType))
  }

  if (!isRecord(value)) {
    return []
  }

  const rawType = readRawType(value, inheritedType)
  if (Array.isArray(value.data)) {
    return value.data.flatMap(item => flattenPayloads(item, rawType))
  }

  if (isRecord(value.data)) {
    const nestedType = readRawType(value.data, rawType)
    const merged: UnknownRecord = { ...value, ...value.data, event: nestedType }
    delete merged.data
    return flattenPayloads(merged, nestedType)
  }

  if (Array.isArray(value.events)) {
    return value.events.flatMap(item => flattenPayloads(item, rawType))
  }

  return [{ ...value, event: rawType }]
}

function eventBase(payload: UnknownRecord, rawType: string, receivedAt: number) {
  return {
    eventId: readText(payload, ['msgId', 'messageId', 'eventId', 'logId']),
    rawType,
    receivedAt,
    source: 'tikfinity' as const,
    user: readUser(payload),
  }
}

function normalizePayload(payload: UnknownRecord, receivedAt: number): TikFinityEvent | undefined {
  const rawType = readRawType(payload, '').toLowerCase()
  const base = eventBase(payload, rawType, receivedAt)
  const comment = readText(payload, ['comment', 'message', 'text', 'commandParams', 'content'])

  if (rawType.includes('gift') || readText(payload, ['giftName', 'giftId'])) {
    const giftType = readNumber(payload, ['giftType', 'gift_type'])
    const repeatEnd = readBoolean(payload, ['repeatEnd', 'repeat_end'])
    if (giftType === 1 && repeatEnd === false) {
      return
    }

    return {
      ...base,
      type: 'gift',
      giftId: readText(payload, ['giftId', 'giftID']),
      giftName: readText(payload, ['giftName', 'gift', 'giftTitle']) ?? 'gift',
      coins: Math.max(0, readNumber(payload, ['coins', 'diamondCount', 'diamond_count']) ?? 0),
      repeatCount: Math.max(1, readNumber(payload, ['repeatCount', 'repeat_count']) ?? 1),
    }
  }

  if (rawType.includes('follow')) {
    return { ...base, type: 'follow' }
  }
  if (rawType.includes('subscribe') || rawType === 'sub') {
    return {
      ...base,
      type: 'subscribe',
      months: readNumber(payload, ['subMonth', 'subscriptionMonth', 'months']),
    }
  }
  if (rawType.includes('share')) {
    return { ...base, type: 'share' }
  }
  if (rawType.includes('like')) {
    return {
      ...base,
      type: 'like',
      likeCount: Math.max(1, readNumber(payload, ['likeCount', 'likes']) ?? 1),
      totalLikeCount: readNumber(payload, ['totalLikeCount', 'totalLikes']),
    }
  }
  if (comment && (rawType.includes('chat') || rawType.includes('comment'))) {
    return { ...base, type: 'comment', text: comment }
  }
}

function isSupportedPayload(payload: UnknownRecord): boolean {
  const rawType = readRawType(payload, '').toLowerCase()
  return rawType.includes('gift')
    || rawType.includes('follow')
    || rawType.includes('subscribe')
    || rawType === 'sub'
    || rawType.includes('share')
    || rawType.includes('like')
    || rawType.includes('chat')
    || rawType.includes('comment')
    || readText(payload, ['giftName', 'giftId']) !== undefined
}

/**
 * Decodes one text frame from the TikFinity LIVE API.
 *
 * The decoder accepts JSON envelopes and Socket.IO event frames. A protocol
 * heartbeat returns a reply but does not count as a TikTok event.
 *
 * @example
 * decodeTikFinityMessage('{"event":"chat","data":{"comment":"Hello"}}')
 * // => { parsed: true, recognized: true, events: [{ type: 'comment', ... }] }
 */
export function decodeTikFinityMessage(raw: string, receivedAt = Date.now()): TikFinityDecodeResult {
  const text = raw.trim()
  if (text === '2') {
    return { parsed: true, recognized: true, events: [], heartbeatReply: '3' }
  }
  if (text === '3' || text === '40' || text === 'probe') {
    return { parsed: true, recognized: true, events: [] }
  }

  const json = text.startsWith('42') ? text.slice(2) : text
  let decoded: unknown
  try {
    decoded = JSON.parse(json)
  }
  catch {
    return { parsed: false, recognized: false, events: [] }
  }

  const payloads = flattenPayloads(decoded)
  const events = payloads
    .map(payload => normalizePayload(payload, receivedAt))
    .filter((event): event is TikFinityEvent => event !== undefined)

  return { parsed: true, recognized: payloads.some(isSupportedPayload), events }
}

/** Replays one recorded TikFinity frame through the production decoder. */
export function decodeTikFinityRecord(record: TikFinityRecord): TikFinityDecodeResult {
  return decodeTikFinityMessage(record.raw, record.recordedAt)
}
