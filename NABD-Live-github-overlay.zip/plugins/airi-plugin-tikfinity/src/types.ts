/** Identifies one TikTok LIVE viewer. */
export interface TikFinityUser {
  id: string
  username?: string
  displayName: string
  avatarUrl?: string
}

interface TikFinityEventBase {
  eventId?: string
  rawType: string
  receivedAt: number
  source: 'tikfinity' | 'tiktok-direct'
  user: TikFinityUser
}

/** Contains one TikTok LIVE comment. */
export interface TikFinityCommentEvent extends TikFinityEventBase {
  type: 'comment'
  text: string
}

/** Contains one completed TikTok LIVE gift event. */
export interface TikFinityGiftEvent extends TikFinityEventBase {
  type: 'gift'
  giftId?: string
  giftName: string
  coins: number
  repeatCount: number
}

/** Contains one TikTok LIVE follow event. */
export interface TikFinityFollowEvent extends TikFinityEventBase {
  type: 'follow'
}

/** Contains one TikTok LIVE share event. */
export interface TikFinityShareEvent extends TikFinityEventBase {
  type: 'share'
}

/** Contains one TikTok LIVE subscription event. */
export interface TikFinitySubscribeEvent extends TikFinityEventBase {
  type: 'subscribe'
  months?: number
}

/** Contains one TikTok LIVE like event. */
export interface TikFinityLikeEvent extends TikFinityEventBase {
  type: 'like'
  likeCount: number
  totalLikeCount?: number
}

/** Contains every live event that the TikFinity decoder supports. */
export type TikFinityEvent
  = | TikFinityCommentEvent
    | TikFinityGiftEvent
    | TikFinityFollowEvent
    | TikFinityShareEvent
    | TikFinitySubscribeEvent
    | TikFinityLikeEvent

/** Reports the result for one TikFinity WebSocket frame. */
export interface TikFinityDecodeResult {
  events: TikFinityEvent[]
  heartbeatReply?: string
  parsed: boolean
  recognized: boolean
}

/** Stores one raw frame and its arrival time for replay. */
export interface TikFinityRecord {
  raw: string
  recordedAt: number
}

/** Reports the current TikFinity connection gate. */
export type TikFinityBridgeStatus
  = | 'idle'
    | 'connecting'
    | 'socket-open'
    | 'verified'
    | 'reconnecting'
    | 'stopped'

/** Reports current counters and the verified connection state. */
export interface TikFinityBridgeSnapshot {
  status: TikFinityBridgeStatus
  rawMessageCount: number
  eventCount: number
  unknownMessageCount: number
  sessionEventCount: number
}

/** Reports whether decoded live events can currently reach AIRI. */
export type TikFinityDeliveryStatus
  = | 'idle'
    | 'connecting'
    | 'ready'
    | 'error'
    | 'stopped'

/** Reports the ordered delivery queue between TikFinity and AIRI. */
export interface TikFinityDeliverySnapshot {
  status: TikFinityDeliveryStatus
  queuedMessageCount: number
  sentMessageCount: number
  droppedMessageCount: number
}
