import type {
  TikFinityBridgeSnapshot,
  TikFinityBridgeStatus,
  TikFinityEvent,
  TikFinityRecord,
} from './types'

import { decodeTikFinityMessage } from './decode'

/** Receives lifecycle callbacks from one TikFinity transport instance. */
export interface TikFinityTransportHandlers {
  open: () => void
  message: (raw: string) => void
  close: () => void
  error: (error: unknown) => void
}

/** Provides the network boundary used by {@link TikFinityBridge}. */
export interface TikFinityTransport {
  connect: (handlers: TikFinityTransportHandlers) => void
  send: (message: string) => void
  close: () => void
}

/** Creates one transport for one TikFinity connection attempt. */
export type TikFinityTransportFactory = (endpoint: string) => TikFinityTransport

/** Configures the TikFinity connection and its observable callbacks. */
export interface TikFinityBridgeOptions {
  endpoint: string
  createTransport?: TikFinityTransportFactory
  reconnectDelayMs?: number
  onEvent: (event: TikFinityEvent) => void
  onRecord?: (record: TikFinityRecord) => void
  onSnapshot?: (snapshot: TikFinityBridgeSnapshot) => void
  onError?: (error: unknown) => void
  now?: () => number
  schedule?: (callback: () => void, delayMs: number) => () => void
}

class NativeWebSocketTransport implements TikFinityTransport {
  private socket?: WebSocket

  constructor(private readonly endpoint: string) {}

  connect(handlers: TikFinityTransportHandlers): void {
    const socket = new WebSocket(this.endpoint)
    this.socket = socket
    socket.addEventListener('open', handlers.open)
    socket.addEventListener('message', (event) => {
      if (typeof event.data === 'string') {
        handlers.message(event.data)
        return
      }
      handlers.error(new Error('TikFinity sent a non-text WebSocket frame.'))
    })
    socket.addEventListener('close', handlers.close)
    socket.addEventListener('error', handlers.error)
  }

  send(message: string): void {
    this.socket?.send(message)
  }

  close(): void {
    this.socket?.close()
  }
}

function defaultSchedule(callback: () => void, delayMs: number): () => void {
  const timer = setTimeout(callback, delayMs)
  return () => clearTimeout(timer)
}

/**
 * Owns the TikFinity connection and its verified-event state.
 *
 * The `socket-open` state only means that the WebSocket transport is open. The bridge
 * enters `verified` after it decodes the first TikTok event in the session.
 */
export class TikFinityBridge {
  private readonly createTransport: TikFinityTransportFactory
  private readonly now: () => number
  private readonly schedule: (callback: () => void, delayMs: number) => () => void
  private readonly recentEvents = new Map<string, number>()
  private transport?: TikFinityTransport
  private cancelReconnect?: () => void
  private active = false
  private status: TikFinityBridgeStatus = 'idle'
  private rawMessageCount = 0
  private eventCount = 0
  private unknownMessageCount = 0
  private sessionEventCount = 0

  constructor(private readonly options: TikFinityBridgeOptions) {
    this.createTransport = options.createTransport ?? (endpoint => new NativeWebSocketTransport(endpoint))
    this.now = options.now ?? Date.now
    this.schedule = options.schedule ?? defaultSchedule
  }

  get snapshot(): TikFinityBridgeSnapshot {
    return {
      status: this.status,
      rawMessageCount: this.rawMessageCount,
      eventCount: this.eventCount,
      unknownMessageCount: this.unknownMessageCount,
      sessionEventCount: this.sessionEventCount,
    }
  }

  start(): void {
    if (this.active) {
      return
    }
    this.active = true
    this.openTransport()
  }

  stop(): void {
    this.active = false
    this.cancelReconnect?.()
    this.cancelReconnect = undefined
    this.transport?.close()
    this.transport = undefined
    this.updateStatus('stopped')
  }

  private openTransport(): void {
    this.cancelReconnect = undefined
    this.sessionEventCount = 0
    this.updateStatus('connecting')
    const transport = this.createTransport(this.options.endpoint)
    this.transport = transport
    transport.connect({
      open: () => {
        if (this.transport === transport) {
          this.updateStatus('socket-open')
        }
      },
      message: (raw) => {
        if (this.transport === transport) {
          this.handleMessage(raw)
        }
      },
      close: () => this.handleClose(transport),
      error: (error) => {
        if (this.transport === transport) {
          this.options.onError?.(error)
        }
      },
    })
  }

  private handleMessage(raw: string): void {
    const receivedAt = this.now()
    this.rawMessageCount += 1
    this.options.onRecord?.({ raw, recordedAt: receivedAt })
    const result = decodeTikFinityMessage(raw, receivedAt)
    if (result.heartbeatReply) {
      this.transport?.send(result.heartbeatReply)
    }
    if (!result.recognized) {
      this.unknownMessageCount += 1
    }

    for (const event of result.events) {
      if (this.isDuplicate(event)) {
        continue
      }
      this.eventCount += 1
      this.sessionEventCount += 1
      this.options.onEvent(event)
    }

    if (this.sessionEventCount > 0) {
      this.updateStatus('verified')
      return
    }
    this.emitSnapshot()
  }

  private isDuplicate(event: TikFinityEvent): boolean {
    let content = ''
    if (event.type === 'comment') {
      content = event.text
    }
    else if (event.type === 'gift') {
      content = `${event.giftId ?? event.giftName}:${event.repeatCount}`
    }
    else if (event.type === 'like') {
      content = String(event.likeCount)
    }
    const key = event.eventId ?? `${event.type}:${event.user.id}:${content}`
    const now = this.now()
    const previous = this.recentEvents.get(key)
    this.recentEvents.set(key, now)

    for (const [recentKey, recordedAt] of this.recentEvents) {
      if (now - recordedAt > 15_000) {
        this.recentEvents.delete(recentKey)
      }
    }
    return previous !== undefined && now - previous < 1_500
  }

  private handleClose(transport: TikFinityTransport): void {
    // A stale connection can close after a new connection becomes active.
    // The transport identity keeps that close event inside its session.
    if (this.transport !== transport) {
      return
    }
    this.transport = undefined
    if (!this.active) {
      return
    }
    this.updateStatus('reconnecting')
    this.cancelReconnect = this.schedule(() => this.openTransport(), this.options.reconnectDelayMs ?? 3_000)
  }

  private updateStatus(status: TikFinityBridgeStatus): void {
    this.status = status
    this.emitSnapshot()
  }

  private emitSnapshot(): void {
    this.options.onSnapshot?.(this.snapshot)
  }
}
