import type { TikFinityEvent, TikFinityUser } from './types'

/** Sets the points that each TikTok LIVE action earns. */
export interface TikFinityPointRules {
  comment: number
  follow: number
  giftCoinMultiplier: number
  likesPerPoint: number
  share: number
  subscribe: number
}

/** Stores one viewer's current score. */
export interface TikFinityViewerScore {
  displayName: string
  points: number
  userId: string
  username?: string
}

/** Stores the active live quiz. */
export interface TikFinityQuiz {
  answers: string[]
  question: string
  rewardPoints: number
  startedAt: number
}

/** Stores the winner of the latest live quiz. */
export interface TikFinityQuizWinner {
  answer: string
  displayName: string
  points: number
  userId: string
}

/** Stores one live poll option and its current vote count. */
export interface TikFinityPollOption {
  label: string
  votes: number
}

/** Stores the active audience poll. */
export interface TikFinityPoll {
  options: TikFinityPollOption[]
  question: string
  startedAt: number
}

/** Stores the final result of the latest audience poll. */
export interface TikFinityPollResult {
  options: TikFinityPollOption[]
  question: string
  winnerLabels: string[]
}

/** Reports the current scores and quiz state. */
export interface TikFinityEngagementSnapshot {
  poll?: TikFinityPoll
  pollResult?: TikFinityPollResult
  quiz?: TikFinityQuiz
  scores: TikFinityViewerScore[]
  winner?: TikFinityQuizWinner
}

/** Reports extra AIRI messages for one TikFinity event. */
export interface TikFinityEngagementResult {
  messages: string[]
  suppressDefault: boolean
}

/** Configures points, saved scores, and state callbacks. */
export interface TikFinityEngagementOptions {
  initialScores?: TikFinityViewerScore[]
  now?: () => number
  onSnapshot?: (snapshot: TikFinityEngagementSnapshot) => void
  rules?: Partial<TikFinityPointRules>
}

const defaultRules: TikFinityPointRules = {
  comment: 1,
  follow: 25,
  giftCoinMultiplier: 1,
  likesPerPoint: 10,
  share: 15,
  subscribe: 100,
}

function normalizeAnswer(value: string): string {
  return value
    .trim()
    .toLocaleLowerCase()
    .replace(/[\u064B-\u065F\u0670\u06D6-\u06ED]/g, '')
    .replace(/ـ/g, '')
    .replace(/[إأآٱ]/g, 'ا')
    .replace(/ى/g, 'ي')
    .replace(/ة/g, 'ه')
    .replace(/[^\p{L}\p{N}\s]/gu, ' ')
    .replace(/\s+/g, ' ')
    .trim()
}

function userLabel(user: TikFinityUser): string {
  if (user.username && user.username !== user.displayName) {
    return `${user.displayName} (@${user.username.replace(/^@/, '')})`
  }
  return user.displayName
}

/** Tracks viewer points and runs a first-correct-answer quiz. */
export class TikFinityEngagementEngine {
  private readonly now: () => number
  private readonly onSnapshot?: (snapshot: TikFinityEngagementSnapshot) => void
  private readonly rules: TikFinityPointRules
  private readonly scores = new Map<string, TikFinityViewerScore>()
  private readonly pollVotes = new Map<string, number>()
  private poll?: TikFinityPoll
  private pollResult?: TikFinityPollResult
  private quiz?: TikFinityQuiz
  private winner?: TikFinityQuizWinner

  constructor(options: TikFinityEngagementOptions = {}) {
    this.now = options.now ?? Date.now
    this.onSnapshot = options.onSnapshot
    const rules = { ...defaultRules, ...options.rules }
    this.rules = {
      comment: Math.max(0, rules.comment),
      follow: Math.max(0, rules.follow),
      giftCoinMultiplier: Math.max(0, rules.giftCoinMultiplier),
      likesPerPoint: Math.max(1, rules.likesPerPoint),
      share: Math.max(0, rules.share),
      subscribe: Math.max(0, rules.subscribe),
    }
    for (const score of options.initialScores ?? []) {
      if (score.userId && Number.isFinite(score.points)) {
        this.scores.set(score.userId, { ...score, points: Math.max(0, Math.floor(score.points)) })
      }
    }
  }

  get snapshot(): TikFinityEngagementSnapshot {
    return {
      poll: this.poll
        ? { ...this.poll, options: this.poll.options.map(option => ({ ...option })) }
        : undefined,
      pollResult: this.pollResult
        ? {
            ...this.pollResult,
            options: this.pollResult.options.map(option => ({ ...option })),
            winnerLabels: [...this.pollResult.winnerLabels],
          }
        : undefined,
      quiz: this.quiz ? { ...this.quiz, answers: [...this.quiz.answers] } : undefined,
      scores: this.topScores(),
      winner: this.winner ? { ...this.winner } : undefined,
    }
  }

  startQuiz(question: string, answers: string[], rewardPoints: number): string {
    const cleanQuestion = question.trim()
    const cleanAnswers = [...new Set(answers.map(answer => answer.trim()).filter(Boolean))]
    if (!cleanQuestion || cleanAnswers.length === 0) {
      throw new Error('A live quiz needs a question and at least one answer.')
    }

    this.quiz = {
      question: cleanQuestion,
      answers: cleanAnswers,
      rewardPoints: Math.max(1, Math.floor(rewardPoints)),
      startedAt: this.now(),
    }
    this.poll = undefined
    this.pollVotes.clear()
    this.winner = undefined
    this.emitSnapshot()
    return `[TikTok LIVE quiz] Ask the audience this question: ${cleanQuestion}. The first correct answer wins ${this.quiz.rewardPoints} points. Do not reveal the answer.`
  }

  cancelQuiz(): void {
    this.quiz = undefined
    this.emitSnapshot()
  }

  startPoll(question: string, options: string[]): string {
    const cleanQuestion = question.trim()
    const cleanOptions = [...new Set(options.map(option => option.trim()).filter(Boolean))]
    if (!cleanQuestion || cleanOptions.length < 2) {
      throw new Error('A live poll needs a question and at least two options.')
    }

    this.poll = {
      question: cleanQuestion,
      options: cleanOptions.map(label => ({ label, votes: 0 })),
      startedAt: this.now(),
    }
    this.pollVotes.clear()
    this.pollResult = undefined
    this.quiz = undefined
    this.emitSnapshot()
    const optionList = cleanOptions.map((label, index) => `${index + 1}. ${label}`).join(', ')
    return `[TikTok LIVE audience poll] Ask the audience: ${cleanQuestion}. They can vote once by writing an option number or name. Options: ${optionList}.`
  }

  stopPoll(): string {
    if (!this.poll) {
      throw new Error('No live poll is active.')
    }

    const highestVotes = Math.max(...this.poll.options.map(option => option.votes))
    const winnerLabels = highestVotes > 0
      ? this.poll.options
          .filter(option => option.votes === highestVotes)
          .map(option => option.label)
      : []
    this.pollResult = {
      question: this.poll.question,
      options: this.poll.options.map(option => ({ ...option })),
      winnerLabels,
    }
    const result = this.poll.options.map(option => `${option.label}: ${option.votes}`).join(', ')
    this.poll = undefined
    this.pollVotes.clear()
    this.emitSnapshot()
    const winner = winnerLabels.length > 0 ? winnerLabels.join(', ') : 'No votes'
    return `[TikTok LIVE poll result] Announce this audience result in the stream language: ${result}. Winner: ${winner}.`
  }

  cancelPoll(): void {
    this.poll = undefined
    this.pollVotes.clear()
    this.emitSnapshot()
  }

  clearScores(): void {
    this.scores.clear()
    this.winner = undefined
    this.emitSnapshot()
  }

  handleEvent(event: TikFinityEvent): TikFinityEngagementResult {
    this.addEventPoints(event)
    if (event.type !== 'comment') {
      this.emitSnapshot()
      return { messages: [], suppressDefault: false }
    }

    const command = normalizeAnswer(event.text)
    if (command === 'نقاط' || command === 'points') {
      const score = this.scores.get(event.user.id)?.points ?? 0
      this.emitSnapshot()
      return {
        messages: [`[TikTok LIVE points] ${userLabel(event.user)} has ${score} points. Tell the viewer their score in the stream language.`],
        suppressDefault: true,
      }
    }

    if (command === 'ترتيب' || command === 'top') {
      const leaders = this.topScores(5)
        .map((score, index) => `${index + 1}. ${score.displayName}: ${score.points}`)
        .join(', ')
      this.emitSnapshot()
      return {
        messages: [`[TikTok LIVE leaderboard] Read this leaderboard in the stream language: ${leaders || 'No scores yet.'}`],
        suppressDefault: true,
      }
    }

    if (this.poll) {
      const optionIndex = this.readPollOption(command)
      if (optionIndex !== undefined) {
        if (!this.pollVotes.has(event.user.id)) {
          this.pollVotes.set(event.user.id, optionIndex)
          this.poll.options[optionIndex]!.votes += 1
        }
        this.emitSnapshot()
        return { messages: [], suppressDefault: true }
      }
    }

    if (this.quiz && this.quiz.answers.some(answer => normalizeAnswer(answer) === command)) {
      const rewardPoints = this.quiz.rewardPoints
      const score = this.addPoints(event.user, rewardPoints)
      this.winner = {
        answer: event.text,
        displayName: event.user.displayName,
        points: score.points,
        userId: event.user.id,
      }
      this.quiz = undefined
      this.emitSnapshot()
      return {
        messages: [`[TikTok LIVE quiz winner] ${userLabel(event.user)} gave the first correct answer: ${event.text}. Congratulate them in the stream language. They won ${rewardPoints} points and now have ${score.points} points.`],
        suppressDefault: true,
      }
    }

    this.emitSnapshot()
    return { messages: [], suppressDefault: false }
  }

  private addEventPoints(event: TikFinityEvent): void {
    switch (event.type) {
      case 'comment':
        this.addPoints(event.user, this.rules.comment)
        break
      case 'follow':
        this.addPoints(event.user, this.rules.follow)
        break
      case 'gift':
        this.addPoints(event.user, event.coins * event.repeatCount * this.rules.giftCoinMultiplier)
        break
      case 'like':
        this.addPoints(event.user, Math.floor(event.likeCount / this.rules.likesPerPoint))
        break
      case 'share':
        this.addPoints(event.user, this.rules.share)
        break
      case 'subscribe':
        this.addPoints(event.user, this.rules.subscribe)
        break
    }
  }

  private addPoints(user: TikFinityUser, value: number): TikFinityViewerScore {
    const current = this.scores.get(user.id)
    const score: TikFinityViewerScore = {
      displayName: user.displayName,
      points: (current?.points ?? 0) + Math.max(0, Math.floor(value)),
      userId: user.id,
      username: user.username,
    }
    this.scores.set(user.id, score)
    return score
  }

  private readPollOption(comment: string): number | undefined {
    if (!this.poll) {
      return
    }

    const number = Number(comment)
    if (Number.isInteger(number) && number >= 1 && number <= this.poll.options.length) {
      return number - 1
    }
    const optionIndex = this.poll.options.findIndex(option => normalizeAnswer(option.label) === comment)
    return optionIndex >= 0 ? optionIndex : undefined
  }

  private topScores(limit = 100): TikFinityViewerScore[] {
    return [...this.scores.values()]
      .sort((left, right) => right.points - left.points || left.displayName.localeCompare(right.displayName))
      .slice(0, limit)
      .map(score => ({ ...score }))
  }

  private emitSnapshot(): void {
    this.onSnapshot?.(this.snapshot)
  }
}
