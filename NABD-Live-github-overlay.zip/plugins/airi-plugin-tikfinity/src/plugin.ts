import type { ClientOptions } from '@proj-airi/server-sdk'

import type { TikFinityBridgeOptions, TikFinityTransportFactory } from './bridge'
import type { TikFinityEngagementOptions, TikFinityEngagementSnapshot } from './engagement'
import type { TikFinityBridgeSnapshot, TikFinityEvent, TikFinityRecord } from './types'

import { TikFinityBridge } from './bridge'
import { TikFinityEngagementEngine } from './engagement'
import { formatTikFinityEvent } from './format'

/** Defines the AIRI input methods that the TikFinity plugin uses. */
export interface AiriInputClient {
  connect: () => Promise<void>
  sendOrThrow: (event: { type: 'input:text', data: { text: string } }) => void
  close: () => void
}

/** Configures the TikFinity endpoint and the AIRI server channel. */
export interface TikFinityAiriPluginOptions {
  tikFinityEndpoint: string
  airiUrl?: string
  airiToken?: string
  includeLikes?: boolean
  createAiriClient?: (options: ClientOptions) => AiriInputClient | Promise<AiriInputClient>
  createTikFinityTransport?: TikFinityTransportFactory
  onTikFinityEvent?: (event: TikFinityEvent) => void
  onTikFinityRecord?: (record: TikFinityRecord) => void
  onTikFinitySnapshot?: (snapshot: TikFinityBridgeSnapshot) => void
  onError?: (error: unknown) => void
  bridge?: Pick<TikFinityBridgeOptions, 'now' | 'schedule' | 'reconnectDelayMs'>
  engagement?: TikFinityEngagementOptions | false
}

/** Connects TikFinity events to the AIRI server channel. */
export class TikFinityAiriPlugin {
  private readonly createAiriClient: (options: ClientOptions) => AiriInputClient | Promise<AiriInputClient>
  private readonly bridge: TikFinityBridge
  private readonly engagement?: TikFinityEngagementEngine
  private airi?: AiriInputClient

  constructor(private readonly options: TikFinityAiriPluginOptions) {
    this.createAiriClient = options.createAiriClient ?? (async (clientOptions) => {
      const { Client } = await import('@proj-airi/server-sdk')
      return new Client(clientOptions)
    })
    this.engagement = options.engagement === false
      ? undefined
      : new TikFinityEngagementEngine(options.engagement)
    this.bridge = new TikFinityBridge({
      endpoint: options.tikFinityEndpoint,
      createTransport: options.createTikFinityTransport,
      reconnectDelayMs: options.bridge?.reconnectDelayMs,
      now: options.bridge?.now,
      schedule: options.bridge?.schedule,
      onError: options.onError,
      onRecord: options.onTikFinityRecord,
      onSnapshot: options.onTikFinitySnapshot,
      onEvent: event => this.forwardEvent(event),
    })
  }

  get tikFinitySnapshot(): TikFinityBridgeSnapshot {
    return this.bridge.snapshot
  }

  /** Returns the current points and quiz state. */
  get engagementSnapshot(): TikFinityEngagementSnapshot | undefined {
    return this.engagement?.snapshot
  }

  async start(): Promise<void> {
    this.airi ??= await this.createAiriClient({
      name: 'proj-airi:plugin-tikfinity',
      url: this.options.airiUrl,
      token: this.options.airiToken,
      autoConnect: false,
    })
    await this.airi.connect()
    this.bridge.start()
  }

  stop(): void {
    this.bridge.stop()
    this.airi?.close()
  }

  /** Starts one first-correct-answer live quiz and asks AIRI to announce it. */
  startQuiz(question: string, answers: string[], rewardPoints: number): void {
    if (!this.engagement) {
      throw new Error('TikFinity engagement is not active.')
    }
    this.sendText(this.engagement.startQuiz(question, answers, rewardPoints))
  }

  /** Stops the current live quiz without changing viewer points. */
  cancelQuiz(): void {
    this.engagement?.cancelQuiz()
  }

  /** Starts one audience poll and asks AIRI to announce its options. */
  startPoll(question: string, options: string[]): void {
    if (!this.engagement) {
      throw new Error('TikFinity engagement is not active.')
    }
    this.sendText(this.engagement.startPoll(question, options))
  }

  /** Ends the audience poll and asks AIRI to announce its result. */
  stopPoll(): void {
    if (!this.engagement) {
      throw new Error('TikFinity engagement is not active.')
    }
    this.sendText(this.engagement.stopPoll())
  }

  /** Stops the audience poll without asking AIRI to announce a result. */
  cancelPoll(): void {
    this.engagement?.cancelPoll()
  }

  /** Removes all saved viewer points from this plugin instance. */
  clearScores(): void {
    this.engagement?.clearScores()
  }

  private forwardEvent(event: TikFinityEvent): void {
    this.options.onTikFinityEvent?.(event)
    const engagement = this.engagement?.handleEvent(event)
    if (!(event.type === 'like' && !this.options.includeLikes) && !engagement?.suppressDefault) {
      this.sendText(formatTikFinityEvent(event))
    }

    for (const message of engagement?.messages ?? []) {
      this.sendText(message)
    }
  }

  private sendText(text: string): void {
    if (!this.airi) {
      this.options.onError?.(new Error('AIRI did not connect before TikFinity sent an event.'))
      return
    }
    this.airi.sendOrThrow({
      type: 'input:text',
      data: { text },
    })
  }
}
