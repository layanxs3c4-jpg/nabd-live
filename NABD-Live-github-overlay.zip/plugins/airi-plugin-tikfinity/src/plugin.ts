import type { ClientOptions } from '@proj-airi/server-sdk'

import type { TikFinityBridgeOptions, TikFinityTransportFactory } from './bridge'
import type { TikFinityEngagementOptions, TikFinityEngagementSnapshot } from './engagement'
import type {
  TikFinityBridgeSnapshot,
  TikFinityDeliverySnapshot,
  TikFinityDeliveryStatus,
  TikFinityEvent,
  TikFinityRecord,
} from './types'

import { TikFinityBridge } from './bridge'
import { TikFinityEngagementEngine } from './engagement'
import { formatTikFinityEvent } from './format'

/** Defines the AIRI input methods that the TikFinity plugin uses. */
export interface AiriInputClient {
  connect: () => Promise<void>
  sendOrThrow: (event: { type: 'input:text', data: { text: string } }) => Promise<void> | void
  close: () => void
}

/** Configures the TikFinity endpoint and the AIRI server channel. */
export interface TikFinityAiriPluginOptions {
  tikFinityEndpoint: string
  airiUrl?: string
  airiToken?: string
  includeLikes?: boolean
  createAiriClient?: (options: ClientOptions) => AiriInputClient | Promise<AiriInputClient>
  createTikFinityTransport?: TikFinityTransportFactory
  onTikFinityEvent?: (event: TikFinityEvent) => void
  onTikFinityRecord?: (record: TikFinityRecord) => void
  onTikFinitySnapshot?: (snapshot: TikFinityBridgeSnapshot) => void
  onDeliverySnapshot?: (snapshot: TikFinityDeliverySnapshot) => void
  onError?: (error: unknown) => void
  maxPendingMessages?: number
  bridge?: Pick<TikFinityBridgeOptions, 'now' | 'schedule' | 'reconnectDelayMs'>
  engagement?: TikFinityEngagementOptions | false
}

/** Connects TikFinity events to the AIRI server channel. */
export class TikFinityAiriPlugin {
  private readonly createAiriClient: (options: ClientOptions) => AiriInputClient | Promise<AiriInputClient>
  private readonly bridge: TikFinityBridge
  private readonly engagement?: TikFinityEngagementEngine
  private airi?: AiriInputClient
  private active = false
  private deliveryStatus: TikFinityDeliveryStatus = 'idle'
  private droppedMessageCount = 0
  private flushing = false
  private lifecycle = 0
  private readonly pendingTexts: string[] = []
  private sentMessageCount = 0

  constructor(private readonly options: TikFinityAiriPluginOptions) {
    this.createAiriClient = options.createAiriClient ?? (async (clientOptions) => {
      const { Client } = await import('@proj-airi/server-sdk')
      return new Client(clientOptions)
    })
    this.engagement = options.engagement === false
      ? undefined
      : new TikFinityEngagementEngine(options.engagement)
    this.bridge = new TikFinityBridge({
      endpoint: options.tikFinityEndpoint,
      createTransport: options.createTikFinityTransport,
      reconnectDelayMs: options.bridge?.reconnectDelayMs,
      now: options.bridge?.now,
      schedule: options.bridge?.schedule,
      onError: options.onError,
      onRecord: options.onTikFinityRecord,
      onSnapshot: options.onTikFinitySnapshot,
      onEvent: event => this.forwardEvent(event),
    })
  }

  get tikFinitySnapshot(): TikFinityBridgeSnapshot {
    return this.bridge.snapshot
  }

  /** Returns the ordered event delivery state between TikFinity and AIRI. */
  get deliverySnapshot(): TikFinityDeliverySnapshot {
    return {
      status: this.deliveryStatus,
      queuedMessageCount: this.pendingTexts.length,
      sentMessageCount: this.sentMessageCount,
      droppedMessageCount: this.droppedMessageCount,
    }
  }

  /** Returns the current points and quiz state. */
  get engagementSnapshot(): TikFinityEngagementSnapshot | undefined {
    return this.engagement?.snapshot
  }

  async start(): Promise<void> {
    if (this.active) {
      return
    }

    this.active = true
    const lifecycle = ++this.lifecycle
    this.updateDeliveryStatus('connecting')

    // TikFinity is a local input source and must remain available while AIRI starts.
    this.bridge.start()
    await this.connectAiri(lifecycle)
  }

  /** Starts AIRI delivery while live events are supplied by an external source. */
  async startExternal(): Promise<void> {
    if (this.active) {
      return
    }

    this.active = true
    const lifecycle = ++this.lifecycle
    this.updateDeliveryStatus('connecting')
    await this.connectAiri(lifecycle)
  }

  /** Supplies one normalized TikTok LIVE event from a non-TikFinity connector. */
  ingestEvent(event: TikFinityEvent): void {
    if (!this.active) {
      return
    }
    this.forwardEvent(event)
  }

  stop(): void {
    this.active = false
    this.lifecycle += 1
    this.bridge.stop()
    this.airi?.close()
    this.airi = undefined
    this.pendingTexts.length = 0
    this.updateDeliveryStatus('stopped')
  }

  /** Starts one first-correct-answer live quiz and asks AIRI to announce it. */
  startQuiz(question: string, answers: string[], rewardPoints: number): void {
    if (!this.engagement) {
      throw new Error('TikFinity engagement is not active.')
    }
    this.sendText(this.engagement.startQuiz(question, answers, rewardPoints))
  }

  /** Stops the current live quiz without changing viewer points. */
  cancelQuiz(): void {
    this.engagement?.cancelQuiz()
  }

  /** Starts one audience poll and asks AIRI to announce its options. */
  startPoll(question: string, options: string[]): void {
    if (!this.engagement) {
      throw new Error('TikFinity engagement is not active.')
    }
    this.sendText(this.engagement.startPoll(question, options))
  }

  /** Ends the audience poll and asks AIRI to announce its result. */
  stopPoll(): void {
    if (!this.engagement) {
      throw new Error('TikFinity engagement is not active.')
    }
    this.sendText(this.engagement.stopPoll())
  }

  /** Stops the audience poll without asking AIRI to announce a result. */
  cancelPoll(): void {
    this.engagement?.cancelPoll()
  }

  /** Removes all saved viewer points from this plugin instance. */
  clearScores(): void {
    this.engagement?.clearScores()
  }

  private forwardEvent(event: TikFinityEvent): void {
    this.options.onTikFinityEvent?.(event)
    const engagement = this.engagement?.handleEvent(event)
    if (!(event.type === 'like' && !this.options.includeLikes) && !engagement?.suppressDefault) {
      this.sendText(formatTikFinityEvent(event))
    }

    for (const message of engagement?.messages ?? []) {
      this.sendText(message)
    }
  }

  private sendText(text: string): void {
    const maxPendingMessages = Math.max(1, this.options.maxPendingMessages ?? 250)
    if (this.pendingTexts.length >= maxPendingMessages) {
      this.pendingTexts.shift()
      this.droppedMessageCount += 1
    }
    this.pendingTexts.push(text)
    this.emitDeliverySnapshot()
    void this.flushPendingTexts(this.lifecycle)
  }

  private async connectAiri(lifecycle: number): Promise<void> {
    try {
      const airi = this.airi ?? await this.createAiriClient({
        name: 'proj-airi:plugin-tikfinity',
        url: this.options.airiUrl,
        token: this.options.airiToken,
        autoConnect: false,
      })
      if (!this.isCurrentLifecycle(lifecycle)) {
        airi.close()
        return
      }

      this.airi = airi
      await airi.connect()
      if (!this.isCurrentLifecycle(lifecycle)) {
        airi.close()
        return
      }

      this.updateDeliveryStatus('ready')
      await this.flushPendingTexts(lifecycle)
    }
    catch (error) {
      if (!this.isCurrentLifecycle(lifecycle)) {
        return
      }
      this.updateDeliveryStatus('error')
      this.options.onError?.(error)
    }
  }

  private async flushPendingTexts(lifecycle: number): Promise<void> {
    if (this.flushing || !this.airi || this.deliveryStatus !== 'ready') {
      return
    }

    const airi = this.airi
    this.flushing = true
    try {
      while (this.pendingTexts.length > 0 && this.isCurrentLifecycle(lifecycle)) {
        const text = this.pendingTexts[0]
        if (!text) {
          break
        }
        await airi.sendOrThrow({
          type: 'input:text',
          data: { text },
        })
        if (!this.isCurrentLifecycle(lifecycle)) {
          return
        }
        this.pendingTexts.shift()
        this.sentMessageCount += 1
        this.emitDeliverySnapshot()
      }
    }
    catch (error) {
      if (this.isCurrentLifecycle(lifecycle)) {
        this.updateDeliveryStatus('error')
        this.options.onError?.(error)
      }
    }
    finally {
      this.flushing = false
      if (this.pendingTexts.length > 0) {
        void this.flushPendingTexts(this.lifecycle)
      }
    }
  }

  private isCurrentLifecycle(lifecycle: number): boolean {
    return this.active && this.lifecycle === lifecycle
  }

  private updateDeliveryStatus(status: TikFinityDeliveryStatus): void {
    this.deliveryStatus = status
    this.emitDeliverySnapshot()
  }

  private emitDeliverySnapshot(): void {
    this.options.onDeliverySnapshot?.(this.deliverySnapshot)
  }
}
