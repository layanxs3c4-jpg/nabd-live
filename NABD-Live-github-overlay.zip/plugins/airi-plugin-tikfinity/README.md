# AIRI TikFinity plugin

This package connects the TikFinity LIVE API to the AIRI server channel.

## What it does

- Connects to a local TikFinity WebSocket endpoint.
- Decodes comments, gifts, follows, subscriptions, shares, and likes.
- Supports JSON envelopes and Socket.IO event frames.
- Sends normalized live events to AIRI as `input:text` messages.
- Opens the TikFinity socket before AIRI finishes connecting.
- Queues early comments and gifts, then delivers them to AIRI in arrival order.
- Records raw frames through a callback for later replay.
- Reports `verified` only after a real TikTok event arrives.
- Tracks viewer points for comments, gifts, follows, shares, and subscriptions.
- Supports the `!نقاط`, `!points`, `!ترتيب`, and `!top` chat commands.
- Runs a first-correct-answer quiz and asks AIRI to announce the winner.
- Runs a one-vote-per-viewer audience poll with live results.

## How to use it

```ts
import { TikFinityAiriPlugin } from '@proj-airi/airi-plugin-tikfinity'

const plugin = new TikFinityAiriPlugin({
  tikFinityEndpoint: 'ws://127.0.0.1:21213/',
  airiUrl: 'ws://localhost:6121/ws',
  onTikFinitySnapshot(snapshot) {
    console.info(snapshot)
  },
})

await plugin.start()
```

Keep the TikFinity desktop app open on the same computer. Use the WebSocket
endpoint that TikFinity displays in its TikTok LIVE API page.

## Connection states

- `socket-open` means that the WebSocket transport is open.
- `verified` means that the plugin decoded at least one live event.
- `reconnecting` means that the transport closed and a retry is pending.

Use `plugin.deliverySnapshot` to inspect the ordered AIRI queue. The queue keeps
up to 250 messages by default. Set `maxPendingMessages` to change that limit.

Do not use `socket-open` as proof that TikFinity sends live events.

## Points and quizzes

The plugin starts its points engine by default. Pass saved scores through the
`engagement.initialScores` option and save new values from
`engagement.onSnapshot`.

```ts
const plugin = new TikFinityAiriPlugin({
  tikFinityEndpoint: 'ws://127.0.0.1:21213/',
  engagement: {
    initialScores: savedScores,
    onSnapshot(snapshot) {
      saveScores(snapshot.scores)
    },
  },
})

await plugin.start()
plugin.startQuiz('What is the capital of Saudi Arabia?', ['Riyadh', 'الرياض'], 50)
plugin.startPoll('Which game comes next?', ['Quiz', 'Challenges'])
```

The first matching comment ends the quiz, gives the reward points, and sends a
winner message to AIRI. AIRI uses its active speech and avatar settings for the
announcement.

Poll viewers can write an option number or its full name. Call
`plugin.stopPoll()` to send the final result to AIRI.

## When to use it

Use this package when an AIRI desktop or server runtime needs TikTok LIVE
events from TikFinity.

## When not to use it

Do not use this package as a direct TikTok client. TikFinity owns the TikTok
connection and must run on the stream computer.
