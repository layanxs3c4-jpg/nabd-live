import { useLocalStorageManualReset } from '@proj-airi/stage-shared/composables'
import { defineStore } from 'pinia'

export const DEFAULT_AVATAR_MOTION_SPEED = 0.65

/** Stores display settings that affect the character motion. */
export const useSettingsAvatar = defineStore('settings-avatar', () => {
  const motionSpeed = useLocalStorageManualReset<number>(
    'settings/avatar/motion-speed',
    DEFAULT_AVATAR_MOTION_SPEED,
  )

  return {
    motionSpeed,
  }
})
