import { createPinia, setActivePinia } from 'pinia'
import { beforeEach, describe, expect, it, vi } from 'vitest'

import { DEFAULT_AVATAR_MOTION_SPEED, useSettingsAvatar } from './avatar'

vi.mock('@proj-airi/stage-shared/composables', async () => {
  const { refManualReset } = await import('@vueuse/core')

  return {
    useLocalStorageManualReset: (_key: string, value: number) => refManualReset(value),
  }
})

describe('settings avatar store', () => {
  beforeEach(() => {
    setActivePinia(createPinia())
  })

  it('starts the character at the calmer NABD motion speed', () => {
    const store = useSettingsAvatar()

    expect(store.motionSpeed).toBe(DEFAULT_AVATAR_MOTION_SPEED)
    expect(store.motionSpeed).toBe(0.65)
  })

  it('keeps a user-selected motion speed', () => {
    const store = useSettingsAvatar()

    store.motionSpeed = 0.4

    expect(store.motionSpeed).toBe(0.4)
  })
})
