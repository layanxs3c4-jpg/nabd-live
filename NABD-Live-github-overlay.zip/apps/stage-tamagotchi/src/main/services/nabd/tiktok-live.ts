import type { WebContents } from 'electron'

import type { TikFinityEvent, TikFinityUser } from '@proj-airi/airi-plugin-tikfinity'

import { app, ipcMain } from 'electron'
import { TikTokLiveConnection } from 'tiktok-live-connector'

const CONNECT_CHANNEL = 'nabd:tiktok-direct:connect'
const DISCONNECT_CHANNEL = 'nabd:tiktok-direct:disconnect'
const EVENT_CHANNEL = 'nabd:tiktok-direct:event'
const STATUS_CHANNEL = 'nabd:tiktok-direct:status'

interface DirectConnection {
  connect: () => Promise<Record<string, unknown>>
  disconnect: () => Promise<void> | void
  on: (event: string, listener: (data: unknown) => void) => unknown
}

let activeConnection: DirectConnection | undefined
let activeOwner: WebContents | undefined

function asRecord(value: unknown): Record<string, unknown> {
  return value && typeof value === 'object' ? value as Record<string, unknown> : {}
}

function stringValue(...values: unknown[]): string | undefined {
  for (const value of values) {
    if (typeof value === 'string' && value.trim())
      return value.trim()
    if (typeof value === 'number' || typeof value === 'bigint')
      return String(value)
  }
}

function numberValue(...values: unknown[]): number {
  for (const value of values) {
    const number = typeof value === 'number' ? value : Number(value)
    if (Number.isFinite(number))
      return number
  }
  return 0
}

function send(owner: WebContents, channel: string, payload: unknown): void {
  if (!owner.isDestroyed())
    owner.send(channel, payload)
}

function eventId(data: Record<string, unknown>, type: string): string | undefined {
  const common = asRecord(data.common)
  return stringValue(data.msgId, data.messageId, common.msgId)
    ?? `${type}:${Date.now()}:${Math.random().toString(36).slice(2)}`
}

function userFrom(data: Record<string, unknown>): TikFinityUser {
  const user = asRecord(data.user)
  const uniqueId = stringValue(user.uniqueId, data.uniqueId, user.username, data.username)
  const id = stringValue(user.userId, user.id, user.secUid, data.userId, uniqueId) ?? 'anonymous'
  const displayName = stringValue(user.nickname, data.nickname, user.displayName, uniqueId) ?? 'TikTok viewer'
  const profilePicture = asRecord(user.profilePicture)
  const avatarUrls = Array.isArray(profilePicture.urlList) ? profilePicture.urlList : []

  return {
    id,
    username: uniqueId,
    displayName,
    avatarUrl: stringValue(avatarUrls[0]),
  }
}

function baseEvent(data: Record<string, unknown>, type: string) {
  return {
    eventId: eventId(data, type),
    rawType: type,
    receivedAt: Date.now(),
    source: 'tiktok-direct' as const,
    user: userFrom(data),
  }
}

function emitEvent(owner: WebContents, event: TikFinityEvent): void {
  send(owner, EVENT_CHANNEL, event)
}

function bindEvents(connection: DirectConnection, owner: WebContents): void {
  connection.on('chat', (payload) => {
    const data = asRecord(payload)
    const text = stringValue(data.comment, data.text)
    if (!text)
      return
    emitEvent(owner, { ...baseEvent(data, 'chat'), type: 'comment', text })
  })

  connection.on('gift', (payload) => {
    const data = asRecord(payload)
    // TikTok emits every step of a streak. Count only the completed streak.
    if (numberValue(data.giftType) === 1 && data.repeatEnd !== true)
      return
    const giftDetails = asRecord(data.giftDetails)
    const gift = asRecord(data.gift)
    emitEvent(owner, {
      ...baseEvent(data, 'gift'),
      type: 'gift',
      giftId: stringValue(data.giftId, giftDetails.giftId, gift.id),
      giftName: stringValue(data.giftName, giftDetails.giftName, gift.name) ?? 'Gift',
      coins: Math.max(0, numberValue(data.diamondCount, giftDetails.diamondCount, gift.diamondCount)),
      repeatCount: Math.max(1, Math.floor(numberValue(data.repeatCount, data.repeat_count) || 1)),
    })
  })

  connection.on('like', (payload) => {
    const data = asRecord(payload)
    emitEvent(owner, {
      ...baseEvent(data, 'like'),
      type: 'like',
      likeCount: Math.max(0, Math.floor(numberValue(data.likeCount, data.count))),
      totalLikeCount: Math.max(0, Math.floor(numberValue(data.totalLikeCount, data.total))),
    })
  })

  connection.on('social', (payload) => {
    const data = asRecord(payload)
    const socialType = [data.displayType, data.label, data.action, data.eventType]
      .map(value => stringValue(value)?.toLowerCase() ?? '')
      .join(' ')
    if (socialType.includes('follow')) {
      emitEvent(owner, { ...baseEvent(data, 'follow'), type: 'follow' })
    }
    else if (socialType.includes('share')) {
      emitEvent(owner, { ...baseEvent(data, 'share'), type: 'share' })
    }
  })

  connection.on('subscribe', (payload) => {
    const data = asRecord(payload)
    emitEvent(owner, {
      ...baseEvent(data, 'subscribe'),
      type: 'subscribe',
      months: Math.max(0, Math.floor(numberValue(data.months, data.monthCount))),
    })
  })

  connection.on('disconnected', () => {
    if (activeConnection === connection) {
      activeConnection = undefined
      activeOwner = undefined
      send(owner, STATUS_CHANNEL, { status: 'stopped', message: 'انقطع اتصال TikTok المباشر. اضغط اتصال للمحاولة مجددًا.' })
    }
  })

  connection.on('error', (error) => {
    if (activeConnection === connection) {
      const message = error instanceof Error ? error.message : String(error)
      send(owner, STATUS_CHANNEL, { status: 'error', message })
    }
  })
}

async function disconnectActive(): Promise<void> {
  const connection = activeConnection
  activeConnection = undefined
  activeOwner = undefined
  if (connection)
    await Promise.resolve(connection.disconnect()).catch(() => undefined)
}

/** Registers the Node-only TikTok connector used by the renderer through safe IPC. */
export function setupNabdTikTokLive(): void {
  ipcMain.handle(CONNECT_CHANNEL, async (event, requestedUsername: unknown) => {
    const username = stringValue(requestedUsername)?.replace(/^@/, '')
    if (!username || !/^[\w.]{2,32}$/u.test(username))
      throw new Error('أدخل اسم مستخدم TikTok الصحيح من دون رابط البث.')

    await disconnectActive()
    const owner = event.sender
    const connection = new TikTokLiveConnection(username, {
      // 2.1.1-beta1 can fail with 403 while loading extended gift metadata.
      // Live gifts still arrive with IDs/counts when this is disabled.
      enableExtendedGiftInfo: false,
    }) as unknown as DirectConnection
    activeConnection = connection
    activeOwner = owner
    bindEvents(connection, owner)
    send(owner, STATUS_CHANNEL, { status: 'connecting' })

    try {
      const state = await connection.connect()
      if (activeConnection !== connection)
        throw new Error('تم إلغاء اتصال TikTok المباشر.')
      const roomId = stringValue(state.roomId)
      send(owner, STATUS_CHANNEL, { status: 'socket-open', roomId })
      return { roomId }
    }
    catch (error) {
      if (activeConnection === connection) {
        activeConnection = undefined
        activeOwner = undefined
      }
      const message = error instanceof Error ? error.message : String(error)
      send(owner, STATUS_CHANNEL, { status: 'error', message })
      throw error
    }
  })

  ipcMain.handle(DISCONNECT_CHANNEL, async (event) => {
    if (!activeOwner || activeOwner.id === event.sender.id)
      await disconnectActive()
  })

  app.once('before-quit', () => {
    void disconnectActive()
  })
}
