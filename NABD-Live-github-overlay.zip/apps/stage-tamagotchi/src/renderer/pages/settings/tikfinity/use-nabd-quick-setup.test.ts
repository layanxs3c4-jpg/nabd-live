import { describe, expect, it } from 'vitest'

import { resolveNabdSetupReadiness, selectNabdChatModel } from './use-nabd-quick-setup'

describe('nabd quick setup', () => {
  it('does not report ready when TikFinity has no configured chat or speech route', () => {
    const readiness = resolveNabdSetupReadiness({
      activeChatModel: '',
      activeChatProvider: '',
      activeSpeechModel: '',
      activeSpeechProvider: 'speech-noop',
      activeSpeechVoice: '',
      chatProviderConfigured: false,
      speechMuted: false,
      speechProviderConfigured: false,
    })

    expect(readiness.chatReady).toBe(false)
    expect(readiness.speechReady).toBe(false)
    expect(readiness.ready).toBe(false)
  })

  it('requires speech output to be unmuted', () => {
    const readiness = resolveNabdSetupReadiness({
      activeChatModel: 'gpt-4o-mini',
      activeChatProvider: 'openai',
      activeSpeechModel: 'gpt-4o-mini-tts',
      activeSpeechProvider: 'openai-audio-speech',
      activeSpeechVoice: 'coral',
      chatProviderConfigured: true,
      speechMuted: true,
      speechProviderConfigured: true,
    })

    expect(readiness.chatReady).toBe(true)
    expect(readiness.speechReady).toBe(true)
    expect(readiness.speechEnabled).toBe(false)
    expect(readiness.ready).toBe(false)
  })

  it('selects a chat model and skips speech-only models', () => {
    expect(selectNabdChatModel([
      'gpt-4o-mini-tts',
      'text-embedding-3-small',
      'gpt-4.1-mini',
    ])).toBe('gpt-4.1-mini')
  })
})
