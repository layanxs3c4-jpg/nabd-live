import { describe, expect, it } from 'vitest'

import { resolveNabdSetupReadiness } from './use-nabd-quick-setup'

describe('nabd quick setup', () => {
  it('does not report ready when TikFinity has no configured chat or speech route', () => {
    const readiness = resolveNabdSetupReadiness({
      activeChatModel: '',
      activeChatProvider: '',
      activeSpeechModel: '',
      activeSpeechProvider: 'speech-noop',
      activeSpeechVoice: '',
      chatProviderConfigured: false,
      speechMuted: false,
      speechProviderConfigured: false,
    })

    expect(readiness.chatReady).toBe(false)
    expect(readiness.speechReady).toBe(false)
    expect(readiness.ready).toBe(false)
  })

  it('uses any chat and speech providers selected in the application', () => {
    const readiness = resolveNabdSetupReadiness({
      activeChatModel: 'my-chat-model',
      activeChatProvider: 'openrouter',
      activeSpeechModel: 'my-speech-model',
      activeSpeechProvider: 'azure-speech',
      activeSpeechVoice: 'ar-SA-HamedNeural',
      chatProviderConfigured: true,
      speechMuted: false,
      speechProviderConfigured: true,
    })

    expect(readiness.chatReady).toBe(true)
    expect(readiness.speechReady).toBe(true)
    expect(readiness.speechEnabled).toBe(true)
    expect(readiness.ready).toBe(true)
  })

  it('requires speech output to be unmuted', () => {
    const readiness = resolveNabdSetupReadiness({
      activeChatModel: 'my-chat-model',
      activeChatProvider: 'openrouter',
      activeSpeechModel: 'my-speech-model',
      activeSpeechProvider: 'azure-speech',
      activeSpeechVoice: 'ar-SA-HamedNeural',
      chatProviderConfigured: true,
      speechMuted: true,
      speechProviderConfigured: true,
    })

    expect(readiness.speechEnabled).toBe(false)
    expect(readiness.ready).toBe(false)
  })
})
