import type { SpeechProviderWithExtraOptions } from '@xsai-ext/providers/utils'

import { errorMessageFrom } from '@moeru/std'
import { useConsciousnessStore } from '@proj-airi/stage-ui/stores/modules/consciousness'
import { useSpeechStore } from '@proj-airi/stage-ui/stores/modules/speech'
import { useProviderConfigStore } from '@proj-airi/stage-ui/stores/providers/config'
import { useProviderStore } from '@proj-airi/stage-ui/stores/providers/provider'
import { useSpeechOutputControlStore } from '@proj-airi/stage-ui/stores/speech-output-control'
import { generateSpeech } from '@xsai/generate-speech'
import { storeToRefs } from 'pinia'
import { computed, ref } from 'vue'

export interface NabdSetupReadinessInput {
  activeChatModel: string
  activeChatProvider: string
  activeSpeechModel: string
  activeSpeechProvider: string
  activeSpeechVoice: string
  chatProviderConfigured: boolean
  speechMuted: boolean
  speechProviderConfigured: boolean
}

export interface NabdSetupReadiness {
  chatReady: boolean
  ready: boolean
  speechEnabled: boolean
  speechReady: boolean
}

/** Uses the providers already selected in AIRI; TikFinity never owns provider credentials. */
export function resolveNabdSetupReadiness(input: NabdSetupReadinessInput): NabdSetupReadiness {
  const chatReady = input.chatProviderConfigured
    && Boolean(input.activeChatProvider)
    && Boolean(input.activeChatModel)
  const speechReady = input.speechProviderConfigured
    && Boolean(input.activeSpeechProvider)
    && Boolean(input.activeSpeechModel)
    && Boolean(input.activeSpeechVoice)
  const speechEnabled = !input.speechMuted

  return {
    chatReady,
    speechReady,
    speechEnabled,
    ready: chatReady && speechReady && speechEnabled,
  }
}

/** Reads the application's active chat/speech routes without adding or changing API keys. */
export function useNabdQuickSetup() {
  const providerConfigStore = useProviderConfigStore()
  const providersStore = useProviderStore()
  const consciousnessStore = useConsciousnessStore()
  const speechStore = useSpeechStore()
  const speechOutputStore = useSpeechOutputControlStore()
  const { activeProvider: activeChatProvider, activeModel: activeChatModel } = storeToRefs(consciousnessStore)
  const {
    activeSpeechModel,
    activeSpeechProvider,
    activeSpeechVoiceId,
  } = storeToRefs(speechStore)
  const { speechMuted } = storeToRefs(speechOutputStore)

  const testingVoice = ref(false)
  const errorMessage = ref('')

  const readiness = computed(() => resolveNabdSetupReadiness({
    activeChatModel: activeChatModel.value,
    activeChatProvider: activeChatProvider.value,
    activeSpeechModel: activeSpeechModel.value,
    activeSpeechProvider: activeSpeechProvider.value,
    activeSpeechVoice: activeSpeechVoiceId.value,
    chatProviderConfigured: Boolean(activeChatProvider.value)
      && providerConfigStore.getProvider(activeChatProvider.value)?.status === 'configured',
    speechMuted: speechMuted.value,
    speechProviderConfigured: Boolean(activeSpeechProvider.value)
      && providerConfigStore.getProvider(activeSpeechProvider.value)?.status === 'configured',
  }))

  const speechEnabled = computed({
    get: () => !speechMuted.value,
    set: value => speechOutputStore.setSpeechMuted(!value),
  })

  function initialize(): void {
    if (activeChatProvider.value)
      providersStore.initializeProvider(activeChatProvider.value)
    if (activeSpeechProvider.value)
      providersStore.initializeProvider(activeSpeechProvider.value)
  }

  async function generateVoicePreview(): Promise<ArrayBuffer | undefined> {
    const providerId = activeSpeechProvider.value
    const model = activeSpeechModel.value
    const voice = activeSpeechVoiceId.value
    if (!readiness.value.speechReady || !providerId || !model || !voice) {
      errorMessage.value = 'اختر مزود الصوت والنموذج والصوت من إعدادات التطبيق أولاً.'
      return
    }

    testingVoice.value = true
    errorMessage.value = ''
    try {
      const provider = await providersStore.getProviderInstance<SpeechProviderWithExtraOptions<string, Record<string, unknown>>>(providerId)
      const config = providerConfigStore.getProviderConfig(providerId) ?? {}
      return await generateSpeech({
        ...provider.speech(model, config),
        input: 'أهلًا! أنا نبض، والصوت المرتبط بالتطبيق يعمل الآن وجاهز للبث.',
        voice,
      })
    }
    catch (error) {
      errorMessage.value = errorMessageFrom(error) ?? 'تعذر تشغيل اختبار الصوت من مزود التطبيق الحالي.'
    }
    finally {
      testingVoice.value = false
    }
  }

  return {
    testingVoice,
    errorMessage,
    readiness,
    speechEnabled,
    initialize,
    generateVoicePreview,
  }
}
