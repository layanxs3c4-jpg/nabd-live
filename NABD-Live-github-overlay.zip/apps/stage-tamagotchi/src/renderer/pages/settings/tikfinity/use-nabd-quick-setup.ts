import type { SpeechProvider } from '@xsai-ext/providers/utils'

import { errorMessageFrom } from '@moeru/std'
import { useAiriCardStore } from '@proj-airi/stage-ui/stores/modules/airi-card'
import { useConsciousnessStore } from '@proj-airi/stage-ui/stores/modules/consciousness'
import { useSpeechStore } from '@proj-airi/stage-ui/stores/modules/speech'
import { useProviderConfigStore } from '@proj-airi/stage-ui/stores/providers/config'
import { useProviderStore } from '@proj-airi/stage-ui/stores/providers/provider'
import { useSpeechOutputControlStore } from '@proj-airi/stage-ui/stores/speech-output-control'
import { generateSpeech } from '@xsai/generate-speech'
import { storeToRefs } from 'pinia'
import { computed, ref } from 'vue'

const CHAT_PROVIDER_ID = 'openai'
const SPEECH_PROVIDER_ID = 'openai-audio-speech'
const OPENAI_BASE_URL = 'https://api.openai.com/v1/'
const DEFAULT_CHAT_MODEL = 'gpt-4o-mini'
const DEFAULT_SPEECH_MODEL = 'gpt-4o-mini-tts'
const DEFAULT_SPEECH_VOICE = 'coral'

export interface NabdSetupReadinessInput {
  activeChatModel: string
  activeChatProvider: string
  activeSpeechModel: string
  activeSpeechProvider: string
  activeSpeechVoice: string
  chatProviderConfigured: boolean
  speechMuted: boolean
  speechProviderConfigured: boolean
}

export interface NabdSetupReadiness {
  chatReady: boolean
  ready: boolean
  speechEnabled: boolean
  speechReady: boolean
}

/** Resolves the three gates required for an audible TikTok reply. */
export function resolveNabdSetupReadiness(input: NabdSetupReadinessInput): NabdSetupReadiness {
  const chatReady = input.chatProviderConfigured
    && input.activeChatProvider === CHAT_PROVIDER_ID
    && Boolean(input.activeChatModel)
  const speechReady = input.speechProviderConfigured
    && input.activeSpeechProvider === SPEECH_PROVIDER_ID
    && Boolean(input.activeSpeechModel)
    && Boolean(input.activeSpeechVoice)
  const speechEnabled = !input.speechMuted

  return {
    chatReady,
    speechReady,
    speechEnabled,
    ready: chatReady && speechReady && speechEnabled,
  }
}

/** Selects one chat model while excluding non-chat OpenAI models. */
export function selectNabdChatModel(modelIds: string[]): string {
  const chatModels = modelIds.filter((modelId) => {
    const normalized = modelId.toLowerCase()
    return !['audio', 'embedding', 'image', 'moderation', 'realtime', 'transcribe', 'tts', 'whisper']
      .some(excluded => normalized.includes(excluded))
  })
  const preferredModels = ['gpt-5-mini', 'gpt-4.1-mini', 'gpt-4o-mini', 'gpt-4o']
  return preferredModels.find(modelId => chatModels.includes(modelId))
    ?? chatModels.find(modelId => modelId.includes('mini'))
    ?? chatModels[0]
    ?? DEFAULT_CHAT_MODEL
}

/** Configures one OpenAI key for chat and speech in NABD. */
export function useNabdQuickSetup() {
  const providerConfigStore = useProviderConfigStore()
  const providersStore = useProviderStore()
  const consciousnessStore = useConsciousnessStore()
  const speechStore = useSpeechStore()
  const airiCardStore = useAiriCardStore()
  const speechOutputStore = useSpeechOutputControlStore()
  const { activeProvider: activeChatProvider, activeModel: activeChatModel } = storeToRefs(consciousnessStore)
  const {
    activeSpeechModel,
    activeSpeechProvider,
    activeSpeechVoice,
    activeSpeechVoiceId,
  } = storeToRefs(speechStore)
  const { speechMuted } = storeToRefs(speechOutputStore)

  const apiKey = ref('')
  const busy = ref(false)
  const testingVoice = ref(false)
  const errorMessage = ref('')
  const saved = ref(false)

  const readiness = computed(() => resolveNabdSetupReadiness({
    activeChatModel: activeChatModel.value,
    activeChatProvider: activeChatProvider.value,
    activeSpeechModel: activeSpeechModel.value,
    activeSpeechProvider: activeSpeechProvider.value,
    activeSpeechVoice: activeSpeechVoiceId.value,
    chatProviderConfigured: providerConfigStore.getProvider(CHAT_PROVIDER_ID)?.status === 'configured',
    speechMuted: speechMuted.value,
    speechProviderConfigured: providerConfigStore.getProvider(SPEECH_PROVIDER_ID)?.status === 'configured',
  }))

  const speechEnabled = computed({
    get: () => !speechMuted.value,
    set: value => speechOutputStore.setSpeechMuted(!value),
  })

  function initialize(): void {
    providersStore.initializeProvider(CHAT_PROVIDER_ID)
    providersStore.initializeProvider(SPEECH_PROVIDER_ID)
    const chatKey = providerConfigStore.getProviderConfig(CHAT_PROVIDER_ID)?.apiKey
    const speechKey = providerConfigStore.getProviderConfig(SPEECH_PROVIDER_ID)?.apiKey
    apiKey.value = ''
    if (typeof chatKey === 'string') {
      apiKey.value = chatKey
    }
    else if (typeof speechKey === 'string') {
      apiKey.value = speechKey
    }
  }

  async function configure(): Promise<boolean> {
    const normalizedApiKey = apiKey.value.trim()
    if (!normalizedApiKey) {
      errorMessage.value = 'أدخل مفتاح OpenAI أولاً.'
      saved.value = false
      return false
    }

    busy.value = true
    saved.value = false
    errorMessage.value = ''
    providersStore.initializeProvider(CHAT_PROVIDER_ID)
    providersStore.initializeProvider(SPEECH_PROVIDER_ID)
    providerConfigStore.markProviderAdded(CHAT_PROVIDER_ID)
    providerConfigStore.markProviderAdded(SPEECH_PROVIDER_ID)

    const chatConfig = {
      ...providerConfigStore.getProviderConfig(CHAT_PROVIDER_ID),
      apiKey: normalizedApiKey,
      baseUrl: OPENAI_BASE_URL,
    }
    const speechConfig = {
      ...providerConfigStore.getProviderConfig(SPEECH_PROVIDER_ID),
      apiKey: normalizedApiKey,
      baseUrl: OPENAI_BASE_URL,
      model: DEFAULT_SPEECH_MODEL,
      voice: DEFAULT_SPEECH_VOICE,
    }

    try {
      await Promise.all([
        providerConfigStore.updateProviderConfig(CHAT_PROVIDER_ID, chatConfig, 'unconfigured'),
        providerConfigStore.updateProviderConfig(SPEECH_PROVIDER_ID, speechConfig, 'unconfigured'),
      ])

      const [chatValidation, speechValidation] = await Promise.all([
        providersStore.validateProviderConfig(CHAT_PROVIDER_ID, chatConfig, { skipChatPingCheck: true }),
        providersStore.validateProviderConfig(SPEECH_PROVIDER_ID, speechConfig),
      ])

      if (chatValidation.valid)
        providersStore.forceProviderConfigured(CHAT_PROVIDER_ID)
      if (speechValidation.valid)
        providersStore.forceProviderConfigured(SPEECH_PROVIDER_ID)

      if (!chatValidation.valid || !speechValidation.valid) {
        errorMessage.value = [chatValidation.reason, speechValidation.reason].filter(Boolean).join(' · ')
        return false
      }

      const chatModels = await providersStore.fetchModelsForProvider(CHAT_PROVIDER_ID)
      const chatModel = selectNabdChatModel(chatModels.map(model => model.id))
      activeChatProvider.value = CHAT_PROVIDER_ID
      activeChatModel.value = chatModel

      activeSpeechProvider.value = SPEECH_PROVIDER_ID
      activeSpeechModel.value = DEFAULT_SPEECH_MODEL
      const voices = await speechStore.loadVoicesForProvider(SPEECH_PROVIDER_ID, DEFAULT_SPEECH_MODEL)
      activeSpeechVoiceId.value = DEFAULT_SPEECH_VOICE
      activeSpeechVoice.value = voices.find(voice => voice.id === DEFAULT_SPEECH_VOICE)

      speechOutputStore.setSpeechMuted(false)
      airiCardStore.updateActiveCardConsciousness({ provider: CHAT_PROVIDER_ID, model: chatModel })
      airiCardStore.updateActiveCardSpeech({
        provider: SPEECH_PROVIDER_ID,
        model: DEFAULT_SPEECH_MODEL,
        voice_id: DEFAULT_SPEECH_VOICE,
      })
      saved.value = true
      return true
    }
    catch (error) {
      errorMessage.value = errorMessageFrom(error) ?? 'تعذر حفظ إعداد نبض.'
      return false
    }
    finally {
      busy.value = false
    }
  }

  async function generateVoicePreview(): Promise<ArrayBuffer | undefined> {
    if (!readiness.value.speechReady) {
      errorMessage.value = 'احفظ إعداد الصوت أولاً.'
      return
    }

    testingVoice.value = true
    errorMessage.value = ''
    try {
      const provider = await providersStore.getProviderInstance<SpeechProvider<string>>(SPEECH_PROVIDER_ID)
      const config = providerConfigStore.getProviderConfig(SPEECH_PROVIDER_ID) ?? {}
      return await generateSpeech({
        ...provider.speech(activeSpeechModel.value || DEFAULT_SPEECH_MODEL, config),
        input: 'أهلًا! أنا نبض، والصوت يعمل الآن وجاهز للبث.',
        voice: activeSpeechVoiceId.value || DEFAULT_SPEECH_VOICE,
      })
    }
    catch (error) {
      errorMessage.value = errorMessageFrom(error) ?? 'تعذر تشغيل اختبار الصوت.'
    }
    finally {
      testingVoice.value = false
    }
  }

  return {
    apiKey,
    busy,
    testingVoice,
    errorMessage,
    saved,
    readiness,
    speechEnabled,
    initialize,
    configure,
    generateVoicePreview,
  }
}
