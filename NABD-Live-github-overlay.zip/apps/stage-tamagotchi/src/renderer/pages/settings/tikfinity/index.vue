<script setup lang="ts">
import type {
  TikFinityBridgeSnapshot,
  TikFinityEngagementSnapshot,
  TikFinityEvent,
  TikFinityRecord,
  TikFinityViewerScore,
} from '@proj-airi/airi-plugin-tikfinity'

import { errorMessageFrom } from '@moeru/std'
import { TikFinityAiriPlugin } from '@proj-airi/airi-plugin-tikfinity'
import { useModsServerChannelStore } from '@proj-airi/stage-ui/stores/mods/api/channel-server'
import { Button, Callout, FieldCheckbox, FieldInput, IconButton } from '@proj-airi/ui'
import { useClipboard, useLocalStorage } from '@vueuse/core'
import { storeToRefs } from 'pinia'
import { computed, onUnmounted, ref, shallowRef } from 'vue'
import { useI18n } from 'vue-i18n'

const { t } = useI18n()
const serverChannelStore = useModsServerChannelStore()
const { connected: airiConnected } = storeToRefs(serverChannelStore)

const endpoint = useLocalStorage('settings/tikfinity/websocket-endpoint', 'ws://localhost:21213')
const includeLikes = useLocalStorage('settings/tikfinity/include-likes', false)
const savedScores = useLocalStorage<TikFinityViewerScore[]>('settings/tikfinity/viewer-scores', [])
const quizQuestion = ref('')
const quizAnswers = ref('')
const quizReward = useLocalStorage('settings/tikfinity/quiz-reward', 50)
const pollQuestion = ref('')
const pollOptions = ref('')
const plugin = shallowRef<TikFinityAiriPlugin>()
const busy = ref(false)
const errorMessage = ref('')
const events = ref<TikFinityEvent[]>([])
const records = ref<TikFinityRecord[]>([])
const engagementSnapshot = ref<TikFinityEngagementSnapshot>({ scores: savedScores.value })
const snapshot = ref<TikFinityBridgeSnapshot>({
  status: 'idle',
  rawMessageCount: 0,
  eventCount: 0,
  unknownMessageCount: 0,
  sessionEventCount: 0,
})

const isActive = computed(() => !['idle', 'stopped'].includes(snapshot.value.status))
const latestRaw = computed(() => records.value[0]?.raw ?? '')
const { copied, copy, isSupported: clipboardSupported } = useClipboard({ source: latestRaw, legacy: true })

const statusLabel = computed(() => t(`settings.pages.tikfinity.status.${snapshot.value.status}`))
const statusClasses = computed(() => {
  if (snapshot.value.status === 'verified') {
    return ['bg-green-500/12', 'text-green-700', 'dark:text-green-300']
  }
  if (snapshot.value.status === 'socket-open') {
    return ['bg-amber-500/12', 'text-amber-700', 'dark:text-amber-300']
  }
  return ['bg-neutral-500/10', 'text-neutral-600', 'dark:text-neutral-300']
})

function eventTitle(event: TikFinityEvent): string {
  return t(`settings.pages.tikfinity.events.${event.type}`)
}

function eventDescription(event: TikFinityEvent): string {
  switch (event.type) {
    case 'comment':
      return event.text
    case 'gift':
      return `${event.giftName} ×${event.repeatCount} · ${event.coins}`
    case 'like':
      return String(event.likeCount)
    case 'subscribe':
      return event.months ? String(event.months) : ''
    default:
      return ''
  }
}

function clearActivity(): void {
  events.value = []
  records.value = []
}

async function connect(): Promise<void> {
  const normalizedEndpoint = endpoint.value.trim()
  if (!/^wss?:\/\//i.test(normalizedEndpoint)) {
    errorMessage.value = t('settings.pages.tikfinity.error.endpoint')
    return
  }

  busy.value = true
  errorMessage.value = ''
  plugin.value?.stop()

  const nextPlugin = new TikFinityAiriPlugin({
    tikFinityEndpoint: normalizedEndpoint,
    includeLikes: includeLikes.value,
    createAiriClient: () => ({
      connect: async () => {
        await serverChannelStore.ensureConnected()
      },
      sendOrThrow: event => serverChannelStore.send(event),
      // The Stage owns this shared channel. Disconnecting TikFinity must not close it.
      close: () => {},
    }),
    onTikFinityEvent: (event) => {
      events.value = [event, ...events.value].slice(0, 30)
    },
    onTikFinityRecord: (record) => {
      records.value = [record, ...records.value].slice(0, 30)
    },
    onTikFinitySnapshot: (value) => {
      snapshot.value = value
    },
    engagement: {
      initialScores: savedScores.value,
      onSnapshot: (value) => {
        engagementSnapshot.value = value
        savedScores.value = value.scores
      },
    },
    onError: (error) => {
      errorMessage.value = errorMessageFrom(error) ?? t('settings.pages.tikfinity.error.connect')
    },
  })

  plugin.value = nextPlugin
  try {
    await nextPlugin.start()
  }
  catch (error) {
    errorMessage.value = errorMessageFrom(error) ?? t('settings.pages.tikfinity.error.connect')
    nextPlugin.stop()
    plugin.value = undefined
  }
  finally {
    busy.value = false
  }
}

function disconnect(): void {
  plugin.value?.cancelQuiz()
  plugin.value?.cancelPoll()
  plugin.value?.stop()
  plugin.value = undefined
}

function startQuiz(): void {
  const answers = quizAnswers.value
    .split(/[،,\n]/)
    .map(answer => answer.trim())
    .filter(Boolean)
  if (!plugin.value || !quizQuestion.value.trim() || answers.length === 0) {
    errorMessage.value = t('settings.pages.tikfinity.error.quiz')
    return
  }

  errorMessage.value = ''
  plugin.value.startQuiz(quizQuestion.value, answers, quizReward.value)
}

function cancelQuiz(): void {
  plugin.value?.cancelQuiz()
}

function clearScores(): void {
  if (plugin.value) {
    plugin.value.clearScores()
    return
  }
  savedScores.value = []
  engagementSnapshot.value = { scores: [] }
}

function startPoll(): void {
  const options = pollOptions.value
    .split(/[،,\n]/)
    .map(option => option.trim())
    .filter(Boolean)
  if (!plugin.value || !pollQuestion.value.trim() || options.length < 2) {
    errorMessage.value = t('settings.pages.tikfinity.error.poll')
    return
  }

  errorMessage.value = ''
  plugin.value.startPoll(pollQuestion.value, options)
}

function stopPoll(): void {
  plugin.value?.stopPoll()
}

onUnmounted(() => plugin.value?.stop())
</script>

<template>
  <div :class="['flex', 'flex-col', 'gap-4', 'pb-12']">
    <Callout theme="orange" :label="t('settings.pages.tikfinity.notice.title')">
      {{ t('settings.pages.tikfinity.notice.description') }}
    </Callout>

    <Callout v-if="errorMessage" theme="orange" :label="t('settings.pages.tikfinity.error.connect')">
      {{ errorMessage }}
    </Callout>

    <section
      :class="[
        'grid gap-4 rounded-2xl p-4',
        'border border-neutral-200/70 dark:border-neutral-800',
        'bg-white/70 dark:bg-neutral-950/60',
        'lg:grid-cols-[minmax(0,1fr)_auto]',
      ]"
    >
      <div :class="['flex', 'flex-col', 'gap-4']">
        <FieldInput
          v-model="endpoint"
          :label="t('settings.pages.tikfinity.endpoint.label')"
          :description="t('settings.pages.tikfinity.endpoint.description')"
          :placeholder="t('settings.pages.tikfinity.endpoint.placeholder')"
          input-class="font-mono"
        />
        <FieldCheckbox
          v-model="includeLikes"
          :label="t('settings.pages.tikfinity.options.includeLikes.label')"
          :description="t('settings.pages.tikfinity.options.includeLikes.description')"
          :disabled="isActive"
        />
      </div>

      <div :class="['flex items-end gap-2', 'lg:min-w-44 lg:flex-col lg:justify-end']">
        <Button
          v-if="!isActive"
          color="primary"
          variant="primary"
          icon="i-solar:link-circle-bold-duotone"
          :label="t('settings.pages.tikfinity.actions.connect')"
          :loading="busy"
          :disabled="busy"
          block
          @click="connect"
        />
        <Button
          v-else
          color="red"
          variant="secondary"
          icon="i-solar:stop-circle-bold-duotone"
          :label="t('settings.pages.tikfinity.actions.disconnect')"
          block
          @click="disconnect"
        />
      </div>
    </section>

    <section
      :class="[
        'grid gap-3 rounded-2xl p-4',
        'border border-neutral-200/70 dark:border-neutral-800',
        'bg-white/70 dark:bg-neutral-950/60',
      ]"
    >
      <div :class="['flex flex-wrap items-center justify-between gap-3']">
        <div>
          <h2 :class="['text-base font-semibold text-neutral-900', 'dark:text-neutral-100']">
            {{ t('settings.pages.tikfinity.status.title') }}
          </h2>
          <p :class="['text-xs text-neutral-500', 'dark:text-neutral-400']">
            {{ airiConnected ? t('settings.pages.tikfinity.status.airi-ready') : t('settings.pages.tikfinity.status.airi-waiting') }}
          </p>
        </div>
        <span
          :class="[
            'rounded-full px-3 py-1 text-xs font-semibold',
            ...statusClasses,
          ]"
          aria-live="polite"
        >
          {{ statusLabel }}
        </span>
      </div>

      <div :class="['grid grid-cols-1 gap-3', 'sm:grid-cols-3']">
        <div
          v-for="counter in [
            { label: t('settings.pages.tikfinity.counters.raw'), value: snapshot.rawMessageCount },
            { label: t('settings.pages.tikfinity.counters.events'), value: snapshot.eventCount },
            { label: t('settings.pages.tikfinity.counters.unknown'), value: snapshot.unknownMessageCount },
          ]"
          :key="counter.label"
          :class="[
            'rounded-xl p-3',
            'bg-neutral-100/70 dark:bg-neutral-900/80',
          ]"
        >
          <div :class="['text-xs text-neutral-500', 'dark:text-neutral-400']">
            {{ counter.label }}
          </div>
          <div :class="['mt-1 text-2xl font-semibold tabular-nums']">
            {{ counter.value }}
          </div>
        </div>
      </div>
    </section>

    <div :class="['grid gap-4', 'lg:grid-cols-2']">
      <section
        :class="[
          'min-h-64 rounded-2xl p-4',
          'border border-neutral-200/70 dark:border-neutral-800',
          'bg-white/70 dark:bg-neutral-950/60',
        ]"
      >
        <div :class="['mb-3 flex items-center justify-between gap-3']">
          <h2 :class="['text-base font-semibold']">
            {{ t('settings.pages.tikfinity.activity.title') }}
          </h2>
          <IconButton
            icon="i-solar:trash-bin-trash-bold-duotone"
            :aria-label="t('settings.pages.tikfinity.actions.clear')"
            :title="t('settings.pages.tikfinity.actions.clear')"
            :disabled="events.length === 0 && records.length === 0"
            @click="clearActivity"
          />
        </div>

        <div v-if="events.length" :class="['flex flex-col gap-2']">
          <div
            v-for="event in events"
            :key="event.eventId ?? `${event.receivedAt}-${event.type}-${event.user.id}`"
            :class="[
              'rounded-xl px-3 py-2',
              'bg-neutral-100/70 dark:bg-neutral-900/80',
            ]"
          >
            <div :class="['flex items-center justify-between gap-3']">
              <strong :class="['truncate text-sm']">{{ event.user.displayName }}</strong>
              <span :class="['text-xs text-primary-600', 'dark:text-primary-300']">{{ eventTitle(event) }}</span>
            </div>
            <p v-if="eventDescription(event)" :class="['mt-1 break-words text-sm text-neutral-600', 'dark:text-neutral-300']">
              {{ eventDescription(event) }}
            </p>
          </div>
        </div>
        <p v-else :class="['py-12 text-center text-sm text-neutral-500', 'dark:text-neutral-400']">
          {{ t('settings.pages.tikfinity.activity.empty') }}
        </p>
      </section>

      <section
        :class="[
          'min-h-64 rounded-2xl p-4',
          'border border-neutral-200/70 dark:border-neutral-800',
          'bg-white/70 dark:bg-neutral-950/60',
        ]"
      >
        <div :class="['mb-3 flex items-center justify-between gap-3']">
          <h2 :class="['text-base font-semibold']">
            {{ t('settings.pages.tikfinity.activity.rawTitle') }}
          </h2>
          <IconButton
            :icon="copied ? 'i-solar:check-circle-bold-duotone' : 'i-solar:copy-line-duotone'"
            :aria-label="copied ? t('settings.pages.tikfinity.actions.copiedRaw') : t('settings.pages.tikfinity.actions.copyRaw')"
            :title="copied ? t('settings.pages.tikfinity.actions.copiedRaw') : t('settings.pages.tikfinity.actions.copyRaw')"
            :disabled="!clipboardSupported || !latestRaw"
            @click="copy()"
          />
        </div>
        <pre
          v-if="latestRaw"
          :class="[
            'max-h-96 overflow-auto rounded-xl p-3',
            'whitespace-pre-wrap break-all text-xs',
            'bg-neutral-950 text-neutral-200',
          ]"
        >{{ latestRaw }}</pre>
        <p v-else :class="['py-12 text-center text-sm text-neutral-500', 'dark:text-neutral-400']">
          {{ t('settings.pages.tikfinity.activity.rawEmpty') }}
        </p>
      </section>
    </div>

    <div :class="['grid gap-4', 'lg:grid-cols-2']">
      <section
        :class="[
          'rounded-2xl p-4',
          'border border-neutral-200/70 dark:border-neutral-800',
          'bg-white/70 dark:bg-neutral-950/60',
        ]"
      >
        <div :class="['mb-4']">
          <h2 :class="['text-base font-semibold']">
            {{ t('settings.pages.tikfinity.quiz.title') }}
          </h2>
          <p :class="['mt-1 text-xs text-neutral-500', 'dark:text-neutral-400']">
            {{ t('settings.pages.tikfinity.quiz.description') }}
          </p>
        </div>

        <div v-if="engagementSnapshot.quiz" :class="['flex flex-col gap-3']">
          <div :class="['rounded-xl p-3', 'bg-primary-500/10']">
            <div :class="['text-xs font-semibold text-primary-700', 'dark:text-primary-300']">
              {{ t('settings.pages.tikfinity.quiz.active') }}
            </div>
            <p :class="['mt-1 text-sm']">
              {{ engagementSnapshot.quiz.question }}
            </p>
          </div>
          <Button
            color="red"
            variant="secondary"
            icon="i-solar:stop-circle-bold-duotone"
            :label="t('settings.pages.tikfinity.quiz.cancel')"
            @click="cancelQuiz"
          />
        </div>

        <div v-else :class="['flex flex-col gap-3']">
          <FieldInput
            v-model="quizQuestion"
            :label="t('settings.pages.tikfinity.quiz.question.label')"
            :placeholder="t('settings.pages.tikfinity.quiz.question.placeholder')"
          />
          <FieldInput
            v-model="quizAnswers"
            :label="t('settings.pages.tikfinity.quiz.answers.label')"
            :description="t('settings.pages.tikfinity.quiz.answers.description')"
            :placeholder="t('settings.pages.tikfinity.quiz.answers.placeholder')"
          />
          <FieldInput
            v-model="quizReward"
            type="number"
            :label="t('settings.pages.tikfinity.quiz.reward.label')"
          />
          <Button
            color="primary"
            variant="primary"
            icon="i-solar:cup-star-bold-duotone"
            :label="t('settings.pages.tikfinity.quiz.start')"
            :disabled="!isActive"
            @click="startQuiz"
          />
        </div>

        <div v-if="engagementSnapshot.winner" :class="['mt-4 rounded-xl p-3', 'bg-green-500/10']">
          <div :class="['text-xs font-semibold text-green-700', 'dark:text-green-300']">
            {{ t('settings.pages.tikfinity.quiz.latestWinner') }}
          </div>
          <p :class="['mt-1 text-sm']">
            {{ engagementSnapshot.winner.displayName }} · {{ engagementSnapshot.winner.answer }}
          </p>
        </div>
      </section>

      <section
        :class="[
          'rounded-2xl p-4',
          'border border-neutral-200/70 dark:border-neutral-800',
          'bg-white/70 dark:bg-neutral-950/60',
        ]"
      >
        <div :class="['mb-3 flex items-center justify-between gap-3']">
          <div>
            <h2 :class="['text-base font-semibold']">
              {{ t('settings.pages.tikfinity.leaderboard.title') }}
            </h2>
            <p :class="['mt-1 text-xs text-neutral-500', 'dark:text-neutral-400']">
              {{ t('settings.pages.tikfinity.leaderboard.commands') }}
            </p>
          </div>
          <IconButton
            icon="i-solar:trash-bin-trash-bold-duotone"
            :aria-label="t('settings.pages.tikfinity.leaderboard.clear')"
            :title="t('settings.pages.tikfinity.leaderboard.clear')"
            :disabled="engagementSnapshot.scores.length === 0"
            @click="clearScores"
          />
        </div>

        <div v-if="engagementSnapshot.scores.length" :class="['flex flex-col gap-2']">
          <div
            v-for="(score, index) in engagementSnapshot.scores.slice(0, 10)"
            :key="score.userId"
            :class="[
              'grid grid-cols-[2rem_minmax(0,1fr)_auto] items-center gap-2 rounded-xl px-3 py-2',
              'bg-neutral-100/70 dark:bg-neutral-900/80',
            ]"
          >
            <span :class="['text-sm font-semibold text-primary-600', 'dark:text-primary-300']">{{ index + 1 }}</span>
            <span :class="['truncate text-sm']">{{ score.displayName }}</span>
            <span :class="['text-sm font-semibold tabular-nums']">{{ score.points }}</span>
          </div>
        </div>
        <p v-else :class="['py-12 text-center text-sm text-neutral-500', 'dark:text-neutral-400']">
          {{ t('settings.pages.tikfinity.leaderboard.empty') }}
        </p>
      </section>
    </div>

    <section
      :class="[
        'rounded-2xl p-4',
        'border border-neutral-200/70 dark:border-neutral-800',
        'bg-white/70 dark:bg-neutral-950/60',
      ]"
    >
      <div :class="['mb-4']">
        <h2 :class="['text-base font-semibold']">
          {{ t('settings.pages.tikfinity.poll.title') }}
        </h2>
        <p :class="['mt-1 text-xs text-neutral-500', 'dark:text-neutral-400']">
          {{ t('settings.pages.tikfinity.poll.description') }}
        </p>
      </div>

      <div v-if="engagementSnapshot.poll" :class="['grid gap-4', 'lg:grid-cols-[minmax(0,1fr)_auto]']">
        <div>
          <p :class="['mb-3 text-sm font-semibold']">
            {{ engagementSnapshot.poll.question }}
          </p>
          <div :class="['grid gap-2', 'sm:grid-cols-2']">
            <div
              v-for="(option, index) in engagementSnapshot.poll.options"
              :key="option.label"
              :class="[
                'grid grid-cols-[2rem_minmax(0,1fr)_auto] items-center gap-2 rounded-xl px-3 py-2',
                'bg-primary-500/10',
              ]"
            >
              <span :class="['text-sm font-semibold text-primary-600', 'dark:text-primary-300']">{{ index + 1 }}</span>
              <span :class="['truncate text-sm']">{{ option.label }}</span>
              <span :class="['text-sm font-semibold tabular-nums']">{{ option.votes }}</span>
            </div>
          </div>
        </div>
        <Button
          color="primary"
          variant="secondary"
          icon="i-solar:flag-2-bold-duotone"
          :label="t('settings.pages.tikfinity.poll.finish')"
          @click="stopPoll"
        />
      </div>

      <div v-else :class="['grid gap-3', 'lg:grid-cols-[minmax(0,1fr)_minmax(0,1fr)_auto] lg:items-end']">
        <FieldInput
          v-model="pollQuestion"
          :label="t('settings.pages.tikfinity.poll.question.label')"
          :placeholder="t('settings.pages.tikfinity.poll.question.placeholder')"
        />
        <FieldInput
          v-model="pollOptions"
          :label="t('settings.pages.tikfinity.poll.options.label')"
          :description="t('settings.pages.tikfinity.poll.options.description')"
          :placeholder="t('settings.pages.tikfinity.poll.options.placeholder')"
        />
        <Button
          color="primary"
          variant="primary"
          icon="i-solar:chart-square-bold-duotone"
          :label="t('settings.pages.tikfinity.poll.start')"
          :disabled="!isActive"
          @click="startPoll"
        />
      </div>

      <div v-if="engagementSnapshot.pollResult" :class="['mt-4 rounded-xl p-3', 'bg-green-500/10']">
        <div :class="['text-xs font-semibold text-green-700', 'dark:text-green-300']">
          {{ t('settings.pages.tikfinity.poll.latestResult') }}
        </div>
        <p :class="['mt-1 text-sm']">
          {{ engagementSnapshot.pollResult.options.map(option => `${option.label}: ${option.votes}`).join(' · ') }}
        </p>
      </div>
    </section>
  </div>
</template>

<route lang="yaml">
meta:
  layout: settings
  titleKey: settings.pages.tikfinity.title
  subtitleKey: settings.title
  descriptionKey: settings.pages.tikfinity.description
  icon: i-simple-icons:tiktok
  settingsEntry: true
  order: 9
  stageTransition:
    name: slide
</route>
