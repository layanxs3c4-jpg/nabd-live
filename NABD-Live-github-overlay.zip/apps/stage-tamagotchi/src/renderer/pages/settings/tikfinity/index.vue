<script setup lang="ts">
import type { TikFinityEvent } from '@proj-airi/airi-plugin-tikfinity'

import { useModsServerChannelStore } from '@proj-airi/stage-ui/stores/mods/api/channel-server'
import { useSettingsAvatar } from '@proj-airi/stage-ui/stores/settings'
import { Button, Callout, FieldCheckbox, FieldInput, FieldRange, IconButton } from '@proj-airi/ui'
import { useClipboard } from '@vueuse/core'
import { storeToRefs } from 'pinia'
import { computed, nextTick, onMounted, onUnmounted, ref } from 'vue'
import { useI18n } from 'vue-i18n'

import { useTikFinityRuntimeStore } from '../../../stores/tikfinity-runtime'
import { useNabdQuickSetup } from './use-nabd-quick-setup'

const { t } = useI18n()
const serverChannelStore = useModsServerChannelStore()
const { connected: airiConnected } = storeToRefs(serverChannelStore)
const runtimeStore = useTikFinityRuntimeStore()
const {
  endpoint,
  includeLikes,
  snapshot,
  events,
  records,
  engagement: engagementSnapshot,
  errorMessage: runtimeErrorMessage,
  busy,
  quizReward,
} = storeToRefs(runtimeStore)
const {
  apiKey,
  busy: setupBusy,
  testingVoice,
  errorMessage: setupErrorMessage,
  saved: setupSaved,
  readiness,
  speechEnabled,
  initialize: initializeQuickSetup,
  configure: configureQuickSetup,
  generateVoicePreview,
} = useNabdQuickSetup()
const { motionSpeed } = storeToRefs(useSettingsAvatar())

const quizQuestion = ref('')
const quizAnswers = ref('')
const pollQuestion = ref('')
const pollOptions = ref('')
const audioUrl = ref('')
const audioPlayer = ref<HTMLAudioElement>()

const isActive = computed(() => !['idle', 'stopped'].includes(snapshot.value.status))
const latestRaw = computed(() => records.value[0]?.raw ?? '')
const { copied, copy, isSupported: clipboardSupported } = useClipboard({ source: latestRaw, legacy: true })
const errorMessage = computed(() => setupErrorMessage.value || runtimeErrorMessage.value)

const statusLabel = computed(() => t(`settings.pages.tikfinity.status.${snapshot.value.status}`))
const statusClasses = computed(() => {
  if (snapshot.value.status === 'verified') {
    return ['bg-green-500/12', 'text-green-700', 'dark:text-green-300']
  }
  if (snapshot.value.status === 'socket-open') {
    return ['bg-amber-500/12', 'text-amber-700', 'dark:text-amber-300']
  }
  return ['bg-neutral-500/10', 'text-neutral-600', 'dark:text-neutral-300']
})

function eventTitle(event: TikFinityEvent): string {
  return t(`settings.pages.tikfinity.events.${event.type}`)
}

function eventDescription(event: TikFinityEvent): string {
  switch (event.type) {
    case 'comment':
      return event.text
    case 'gift':
      return `${event.giftName} ×${event.repeatCount} · ${event.coins}`
    case 'like':
      return String(event.likeCount)
    case 'subscribe':
      return event.months ? String(event.months) : ''
    default:
      return ''
  }
}

function clearActivity(): void {
  runtimeStore.clearActivity()
}

function connect(): void {
  const normalizedEndpoint = endpoint.value.trim()
  if (!/^wss?:\/\//i.test(normalizedEndpoint)) {
    runtimeErrorMessage.value = t('settings.pages.tikfinity.error.endpoint')
    return
  }
  runtimeStore.connect()
}

function disconnect(): void {
  runtimeStore.disconnect()
}

function startQuiz(): void {
  const answers = quizAnswers.value
    .split(/[،,\n]/)
    .map(answer => answer.trim())
    .filter(Boolean)
  if (!isActive.value || !quizQuestion.value.trim() || answers.length === 0) {
    runtimeErrorMessage.value = t('settings.pages.tikfinity.error.quiz')
    return
  }

  runtimeErrorMessage.value = ''
  runtimeStore.startQuiz(quizQuestion.value, answers, quizReward.value)
}

function cancelQuiz(): void {
  runtimeStore.cancelQuiz()
}

function clearScores(): void {
  runtimeStore.clearScores()
}

function startPoll(): void {
  const options = pollOptions.value
    .split(/[،,\n]/)
    .map(option => option.trim())
    .filter(Boolean)
  if (!isActive.value || !pollQuestion.value.trim() || options.length < 2) {
    runtimeErrorMessage.value = t('settings.pages.tikfinity.error.poll')
    return
  }

  runtimeErrorMessage.value = ''
  runtimeStore.startPoll(pollQuestion.value, options)
}

function stopPoll(): void {
  runtimeStore.stopPoll()
}

async function testVoice(): Promise<void> {
  const audio = await generateVoicePreview()
  if (!audio)
    return

  if (audioUrl.value)
    URL.revokeObjectURL(audioUrl.value)
  audioUrl.value = URL.createObjectURL(new Blob([audio], { type: 'audio/mpeg' }))
  await nextTick()
  await audioPlayer.value?.play().catch(() => undefined)
}

onMounted(() => {
  runtimeStore.initializeClient()
  initializeQuickSetup()
})

onUnmounted(() => {
  if (audioUrl.value)
    URL.revokeObjectURL(audioUrl.value)
})
</script>

<template>
  <div :class="['flex', 'flex-col', 'gap-4', 'pb-12']">
    <Callout theme="orange" :label="t('settings.pages.tikfinity.notice.title')">
      {{ t('settings.pages.tikfinity.notice.description') }}
    </Callout>

    <Callout v-if="errorMessage" theme="orange" :label="t('settings.pages.tikfinity.quickSetup.errorTitle')">
      {{ errorMessage }}
    </Callout>

    <Callout v-if="setupSaved" theme="lime" :label="t('settings.pages.tikfinity.quickSetup.savedTitle')">
      {{ t('settings.pages.tikfinity.quickSetup.savedDescription') }}
    </Callout>

    <section
      dir="rtl"
      :class="[
        'grid gap-5 rounded-2xl p-5',
        'border border-primary-300/60 dark:border-primary-700/60',
        'bg-primary-50/70 dark:bg-primary-950/20',
      ]"
    >
      <div>
        <h2 :class="['text-lg font-bold text-neutral-900', 'dark:text-neutral-100']">
          {{ t('settings.pages.tikfinity.quickSetup.title') }}
        </h2>
        <p :class="['mt-1 text-sm text-neutral-600', 'dark:text-neutral-300']">
          {{ t('settings.pages.tikfinity.quickSetup.description') }}
        </p>
      </div>

      <div :class="['grid grid-cols-2 gap-2', 'lg:grid-cols-4']">
        <div
          v-for="gate in [
            { ready: readiness.chatReady, label: t('settings.pages.tikfinity.quickSetup.gates.chat') },
            { ready: readiness.speechReady, label: t('settings.pages.tikfinity.quickSetup.gates.speech') },
            { ready: readiness.speechEnabled, label: t('settings.pages.tikfinity.quickSetup.gates.output') },
            { ready: snapshot.status === 'verified', label: t('settings.pages.tikfinity.quickSetup.gates.tikfinity') },
          ]"
          :key="gate.label"
          :class="[
            'flex items-center gap-2 rounded-xl px-3 py-2 text-sm font-semibold',
            gate.ready
              ? 'bg-green-500/12 text-green-700 dark:text-green-300'
              : 'bg-amber-500/12 text-amber-700 dark:text-amber-300',
          ]"
        >
          <span :class="[gate.ready ? 'i-solar:check-circle-bold-duotone' : 'i-solar:danger-circle-bold-duotone', 'text-lg']" />
          <span>{{ gate.label }}</span>
        </div>
      </div>

      <div :class="['grid gap-4', 'lg:grid-cols-[minmax(0,1fr)_minmax(16rem,0.55fr)]']">
        <div :class="['flex flex-col gap-3']">
          <FieldInput
            v-model="apiKey"
            type="password"
            :label="t('settings.pages.tikfinity.quickSetup.apiKey.label')"
            :description="t('settings.pages.tikfinity.quickSetup.apiKey.description')"
            placeholder="sk-..."
            input-class="font-mono"
          />
          <FieldCheckbox
            v-model="speechEnabled"
            :label="t('settings.pages.tikfinity.quickSetup.output.label')"
            :description="t('settings.pages.tikfinity.quickSetup.output.description')"
          />
          <div :class="['flex flex-wrap gap-2']">
            <Button
              color="primary"
              variant="primary"
              icon="i-solar:diskette-bold-duotone"
              :label="t('settings.pages.tikfinity.quickSetup.actions.save')"
              :loading="setupBusy"
              :disabled="setupBusy || !apiKey.trim()"
              @click="configureQuickSetup"
            />
            <Button
              color="primary"
              variant="secondary"
              icon="i-solar:volume-loud-bold-duotone"
              :label="t('settings.pages.tikfinity.quickSetup.actions.testVoice')"
              :loading="testingVoice"
              :disabled="testingVoice || !readiness.speechReady"
              @click="testVoice"
            />
          </div>
          <audio v-if="audioUrl" ref="audioPlayer" :src="audioUrl" controls :class="['w-full']" />
        </div>

        <div
          :class="[
            'rounded-xl p-4',
            'bg-white/75 dark:bg-neutral-950/50',
          ]"
        >
          <FieldRange
            v-model="motionSpeed"
            :label="t('settings.pages.tikfinity.quickSetup.motion.label')"
            :description="t('settings.pages.tikfinity.quickSetup.motion.description')"
            :min="0.25"
            :max="1.25"
            :step="0.05"
            :format-value="value => `${Math.round(value * 100)}%`"
          />
          <p :class="['mt-3 text-xs text-neutral-500', 'dark:text-neutral-400']">
            {{ t('settings.pages.tikfinity.quickSetup.motion.hint') }}
          </p>
        </div>
      </div>
    </section>

    <section
      :class="[
        'grid gap-4 rounded-2xl p-4',
        'border border-neutral-200/70 dark:border-neutral-800',
        'bg-white/70 dark:bg-neutral-950/60',
        'lg:grid-cols-[minmax(0,1fr)_auto]',
      ]"
    >
      <div :class="['flex', 'flex-col', 'gap-4']">
        <FieldInput
          v-model="endpoint"
          :label="t('settings.pages.tikfinity.endpoint.label')"
          :description="t('settings.pages.tikfinity.endpoint.description')"
          :placeholder="t('settings.pages.tikfinity.endpoint.placeholder')"
          input-class="font-mono"
        />
        <FieldCheckbox
          v-model="includeLikes"
          :label="t('settings.pages.tikfinity.options.includeLikes.label')"
          :description="t('settings.pages.tikfinity.options.includeLikes.description')"
          :disabled="isActive"
        />
      </div>

      <div :class="['flex items-end gap-2', 'lg:min-w-44 lg:flex-col lg:justify-end']">
        <Button
          v-if="!isActive"
          color="primary"
          variant="primary"
          icon="i-solar:link-circle-bold-duotone"
          :label="t('settings.pages.tikfinity.actions.connect')"
          :loading="busy"
          :disabled="busy"
          block
          @click="connect"
        />
        <Button
          v-else
          color="red"
          variant="secondary"
          icon="i-solar:stop-circle-bold-duotone"
          :label="t('settings.pages.tikfinity.actions.disconnect')"
          block
          @click="disconnect"
        />
      </div>
    </section>

    <section
      :class="[
        'grid gap-3 rounded-2xl p-4',
        'border border-neutral-200/70 dark:border-neutral-800',
        'bg-white/70 dark:bg-neutral-950/60',
      ]"
    >
      <div :class="['flex flex-wrap items-center justify-between gap-3']">
        <div>
          <h2 :class="['text-base font-semibold text-neutral-900', 'dark:text-neutral-100']">
            {{ t('settings.pages.tikfinity.status.title') }}
          </h2>
          <p :class="['text-xs text-neutral-500', 'dark:text-neutral-400']">
            {{ airiConnected ? t('settings.pages.tikfinity.status.airi-ready') : t('settings.pages.tikfinity.status.airi-waiting') }}
          </p>
        </div>
        <span
          :class="[
            'rounded-full px-3 py-1 text-xs font-semibold',
            ...statusClasses,
          ]"
          aria-live="polite"
        >
          {{ statusLabel }}
        </span>
      </div>

      <div :class="['grid grid-cols-1 gap-3', 'sm:grid-cols-3']">
        <div
          v-for="counter in [
            { label: t('settings.pages.tikfinity.counters.raw'), value: snapshot.rawMessageCount },
            { label: t('settings.pages.tikfinity.counters.events'), value: snapshot.eventCount },
            { label: t('settings.pages.tikfinity.counters.unknown'), value: snapshot.unknownMessageCount },
          ]"
          :key="counter.label"
          :class="[
            'rounded-xl p-3',
            'bg-neutral-100/70 dark:bg-neutral-900/80',
          ]"
        >
          <div :class="['text-xs text-neutral-500', 'dark:text-neutral-400']">
            {{ counter.label }}
          </div>
          <div :class="['mt-1 text-2xl font-semibold tabular-nums']">
            {{ counter.value }}
          </div>
        </div>
      </div>
    </section>

    <div :class="['grid gap-4', 'lg:grid-cols-2']">
      <section
        :class="[
          'min-h-64 rounded-2xl p-4',
          'border border-neutral-200/70 dark:border-neutral-800',
          'bg-white/70 dark:bg-neutral-950/60',
        ]"
      >
        <div :class="['mb-3 flex items-center justify-between gap-3']">
          <h2 :class="['text-base font-semibold']">
            {{ t('settings.pages.tikfinity.activity.title') }}
          </h2>
          <IconButton
            icon="i-solar:trash-bin-trash-bold-duotone"
            :aria-label="t('settings.pages.tikfinity.actions.clear')"
            :title="t('settings.pages.tikfinity.actions.clear')"
            :disabled="events.length === 0 && records.length === 0"
            @click="clearActivity"
          />
        </div>

        <div v-if="events.length" :class="['flex flex-col gap-2']">
          <div
            v-for="event in events"
            :key="event.eventId ?? `${event.receivedAt}-${event.type}-${event.user.id}`"
            :class="[
              'rounded-xl px-3 py-2',
              'bg-neutral-100/70 dark:bg-neutral-900/80',
            ]"
          >
            <div :class="['flex items-center justify-between gap-3']">
              <strong :class="['truncate text-sm']">{{ event.user.displayName }}</strong>
              <span :class="['text-xs text-primary-600', 'dark:text-primary-300']">{{ eventTitle(event) }}</span>
            </div>
            <p v-if="eventDescription(event)" :class="['mt-1 break-words text-sm text-neutral-600', 'dark:text-neutral-300']">
              {{ eventDescription(event) }}
            </p>
          </div>
        </div>
        <p v-else :class="['py-12 text-center text-sm text-neutral-500', 'dark:text-neutral-400']">
          {{ t('settings.pages.tikfinity.activity.empty') }}
        </p>
      </section>

      <section
        :class="[
          'min-h-64 rounded-2xl p-4',
          'border border-neutral-200/70 dark:border-neutral-800',
          'bg-white/70 dark:bg-neutral-950/60',
        ]"
      >
        <div :class="['mb-3 flex items-center justify-between gap-3']">
          <h2 :class="['text-base font-semibold']">
            {{ t('settings.pages.tikfinity.activity.rawTitle') }}
          </h2>
          <IconButton
            :icon="copied ? 'i-solar:check-circle-bold-duotone' : 'i-solar:copy-line-duotone'"
            :aria-label="copied ? t('settings.pages.tikfinity.actions.copiedRaw') : t('settings.pages.tikfinity.actions.copyRaw')"
            :title="copied ? t('settings.pages.tikfinity.actions.copiedRaw') : t('settings.pages.tikfinity.actions.copyRaw')"
            :disabled="!clipboardSupported || !latestRaw"
            @click="copy()"
          />
        </div>
        <pre
          v-if="latestRaw"
          :class="[
            'max-h-96 overflow-auto rounded-xl p-3',
            'whitespace-pre-wrap break-all text-xs',
            'bg-neutral-950 text-neutral-200',
          ]"
        >{{ latestRaw }}</pre>
        <p v-else :class="['py-12 text-center text-sm text-neutral-500', 'dark:text-neutral-400']">
          {{ t('settings.pages.tikfinity.activity.rawEmpty') }}
        </p>
      </section>
    </div>

    <div :class="['grid gap-4', 'lg:grid-cols-2']">
      <section
        :class="[
          'rounded-2xl p-4',
          'border border-neutral-200/70 dark:border-neutral-800',
          'bg-white/70 dark:bg-neutral-950/60',
        ]"
      >
        <div :class="['mb-4']">
          <h2 :class="['text-base font-semibold']">
            {{ t('settings.pages.tikfinity.quiz.title') }}
          </h2>
          <p :class="['mt-1 text-xs text-neutral-500', 'dark:text-neutral-400']">
            {{ t('settings.pages.tikfinity.quiz.description') }}
          </p>
        </div>

        <div v-if="engagementSnapshot.quiz" :class="['flex flex-col gap-3']">
          <div :class="['rounded-xl p-3', 'bg-primary-500/10']">
            <div :class="['text-xs font-semibold text-primary-700', 'dark:text-primary-300']">
              {{ t('settings.pages.tikfinity.quiz.active') }}
            </div>
            <p :class="['mt-1 text-sm']">
              {{ engagementSnapshot.quiz.question }}
            </p>
          </div>
          <Button
            color="red"
            variant="secondary"
            icon="i-solar:stop-circle-bold-duotone"
            :label="t('settings.pages.tikfinity.quiz.cancel')"
            @click="cancelQuiz"
          />
        </div>

        <div v-else :class="['flex flex-col gap-3']">
          <FieldInput
            v-model="quizQuestion"
            :label="t('settings.pages.tikfinity.quiz.question.label')"
            :placeholder="t('settings.pages.tikfinity.quiz.question.placeholder')"
          />
          <FieldInput
            v-model="quizAnswers"
            :label="t('settings.pages.tikfinity.quiz.answers.label')"
            :description="t('settings.pages.tikfinity.quiz.answers.description')"
            :placeholder="t('settings.pages.tikfinity.quiz.answers.placeholder')"
          />
          <FieldInput
            v-model="quizReward"
            type="number"
            :label="t('settings.pages.tikfinity.quiz.reward.label')"
          />
          <Button
            color="primary"
            variant="primary"
            icon="i-solar:cup-star-bold-duotone"
            :label="t('settings.pages.tikfinity.quiz.start')"
            :disabled="!isActive"
            @click="startQuiz"
          />
        </div>

        <div v-if="engagementSnapshot.winner" :class="['mt-4 rounded-xl p-3', 'bg-green-500/10']">
          <div :class="['text-xs font-semibold text-green-700', 'dark:text-green-300']">
            {{ t('settings.pages.tikfinity.quiz.latestWinner') }}
          </div>
          <p :class="['mt-1 text-sm']">
            {{ engagementSnapshot.winner.displayName }} · {{ engagementSnapshot.winner.answer }}
          </p>
        </div>
      </section>

      <section
        :class="[
          'rounded-2xl p-4',
          'border border-neutral-200/70 dark:border-neutral-800',
          'bg-white/70 dark:bg-neutral-950/60',
        ]"
      >
        <div :class="['mb-3 flex items-center justify-between gap-3']">
          <div>
            <h2 :class="['text-base font-semibold']">
              {{ t('settings.pages.tikfinity.leaderboard.title') }}
            </h2>
            <p :class="['mt-1 text-xs text-neutral-500', 'dark:text-neutral-400']">
              {{ t('settings.pages.tikfinity.leaderboard.commands') }}
            </p>
          </div>
          <IconButton
            icon="i-solar:trash-bin-trash-bold-duotone"
            :aria-label="t('settings.pages.tikfinity.leaderboard.clear')"
            :title="t('settings.pages.tikfinity.leaderboard.clear')"
            :disabled="engagementSnapshot.scores.length === 0"
            @click="clearScores"
          />
        </div>

        <div v-if="engagementSnapshot.scores.length" :class="['flex flex-col gap-2']">
          <div
            v-for="(score, index) in engagementSnapshot.scores.slice(0, 10)"
            :key="score.userId"
            :class="[
              'grid grid-cols-[2rem_minmax(0,1fr)_auto] items-center gap-2 rounded-xl px-3 py-2',
              'bg-neutral-100/70 dark:bg-neutral-900/80',
            ]"
          >
            <span :class="['text-sm font-semibold text-primary-600', 'dark:text-primary-300']">{{ index + 1 }}</span>
            <span :class="['truncate text-sm']">{{ score.displayName }}</span>
            <span :class="['text-sm font-semibold tabular-nums']">{{ score.points }}</span>
          </div>
        </div>
        <p v-else :class="['py-12 text-center text-sm text-neutral-500', 'dark:text-neutral-400']">
          {{ t('settings.pages.tikfinity.leaderboard.empty') }}
        </p>
      </section>
    </div>

    <section
      :class="[
        'rounded-2xl p-4',
        'border border-neutral-200/70 dark:border-neutral-800',
        'bg-white/70 dark:bg-neutral-950/60',
      ]"
    >
      <div :class="['mb-4']">
        <h2 :class="['text-base font-semibold']">
          {{ t('settings.pages.tikfinity.poll.title') }}
        </h2>
        <p :class="['mt-1 text-xs text-neutral-500', 'dark:text-neutral-400']">
          {{ t('settings.pages.tikfinity.poll.description') }}
        </p>
      </div>

      <div v-if="engagementSnapshot.poll" :class="['grid gap-4', 'lg:grid-cols-[minmax(0,1fr)_auto]']">
        <div>
          <p :class="['mb-3 text-sm font-semibold']">
            {{ engagementSnapshot.poll.question }}
          </p>
          <div :class="['grid gap-2', 'sm:grid-cols-2']">
            <div
              v-for="(option, index) in engagementSnapshot.poll.options"
              :key="option.label"
              :class="[
                'grid grid-cols-[2rem_minmax(0,1fr)_auto] items-center gap-2 rounded-xl px-3 py-2',
                'bg-primary-500/10',
              ]"
            >
              <span :class="['text-sm font-semibold text-primary-600', 'dark:text-primary-300']">{{ index + 1 }}</span>
              <span :class="['truncate text-sm']">{{ option.label }}</span>
              <span :class="['text-sm font-semibold tabular-nums']">{{ option.votes }}</span>
            </div>
          </div>
        </div>
        <Button
          color="primary"
          variant="secondary"
          icon="i-solar:flag-2-bold-duotone"
          :label="t('settings.pages.tikfinity.poll.finish')"
          @click="stopPoll"
        />
      </div>

      <div v-else :class="['grid gap-3', 'lg:grid-cols-[minmax(0,1fr)_minmax(0,1fr)_auto] lg:items-end']">
        <FieldInput
          v-model="pollQuestion"
          :label="t('settings.pages.tikfinity.poll.question.label')"
          :placeholder="t('settings.pages.tikfinity.poll.question.placeholder')"
        />
        <FieldInput
          v-model="pollOptions"
          :label="t('settings.pages.tikfinity.poll.options.label')"
          :description="t('settings.pages.tikfinity.poll.options.description')"
          :placeholder="t('settings.pages.tikfinity.poll.options.placeholder')"
        />
        <Button
          color="primary"
          variant="primary"
          icon="i-solar:chart-square-bold-duotone"
          :label="t('settings.pages.tikfinity.poll.start')"
          :disabled="!isActive"
          @click="startPoll"
        />
      </div>

      <div v-if="engagementSnapshot.pollResult" :class="['mt-4 rounded-xl p-3', 'bg-green-500/10']">
        <div :class="['text-xs font-semibold text-green-700', 'dark:text-green-300']">
          {{ t('settings.pages.tikfinity.poll.latestResult') }}
        </div>
        <p :class="['mt-1 text-sm']">
          {{ engagementSnapshot.pollResult.options.map(option => `${option.label}: ${option.votes}`).join(' · ') }}
        </p>
      </div>
    </section>
  </div>
</template>

<route lang="yaml">
meta:
  layout: settings
  titleKey: settings.pages.tikfinity.title
  subtitleKey: settings.title
  descriptionKey: settings.pages.tikfinity.description
  icon: i-simple-icons:tiktok
  settingsEntry: true
  order: 9
  stageTransition:
    name: slide
</route>
