import type {
  TikFinityBridgeSnapshot,
  TikFinityDeliverySnapshot,
  TikFinityEngagementSnapshot,
  TikFinityEvent,
  TikFinityRecord,
  TikFinityViewerScore,
} from '@proj-airi/airi-plugin-tikfinity'

import { errorMessageFrom } from '@moeru/std'
import { TikFinityAiriPlugin } from '@proj-airi/airi-plugin-tikfinity'
import { useModsServerChannelStore } from '@proj-airi/stage-ui/stores/mods/api/channel-server'
import { useBroadcastChannel, useLocalStorage } from '@vueuse/core'
import { defineStore } from 'pinia'
import { ref, shallowRef, toRaw, watch } from 'vue'

interface RuntimeState {
  delivery: TikFinityDeliverySnapshot
  engagement: TikFinityEngagementSnapshot
  errorMessage: string
  events: TikFinityEvent[]
  records: TikFinityRecord[]
  snapshot: TikFinityBridgeSnapshot
}

export type TikTokEventSource = 'tikfinity' | 'tiktok-direct'

type RuntimeCommand
  = | { type: 'cancel-poll' }
    | { type: 'cancel-quiz' }
    | { type: 'clear-activity' }
    | { type: 'clear-scores' }
    | { type: 'connect', endpoint: string, includeLikes: boolean, source: TikTokEventSource, username: string }
    | { type: 'disconnect' }
    | { type: 'request-state' }
    | { type: 'start-poll', question: string, options: string[] }
    | { type: 'start-quiz', question: string, answers: string[], rewardPoints: number }
    | { type: 'stop-poll' }

type RuntimeMessage
  = | { kind: 'command', command: RuntimeCommand }
    | { kind: 'state', state: RuntimeState }

function idleSnapshot(): TikFinityBridgeSnapshot {
  return {
    status: 'idle',
    rawMessageCount: 0,
    eventCount: 0,
    unknownMessageCount: 0,
    sessionEventCount: 0,
  }
}

function idleDeliverySnapshot(): TikFinityDeliverySnapshot {
  return {
    status: 'idle',
    queuedMessageCount: 0,
    sentMessageCount: 0,
    droppedMessageCount: 0,
  }
}

/** Keeps the TikFinity connection in the main character window. */
export const useTikFinityRuntimeStore = defineStore('nabd-tikfinity-runtime', () => {
  const serverChannelStore = useModsServerChannelStore()
  const endpoint = useLocalStorage('settings/tikfinity/websocket-endpoint', 'ws://127.0.0.1:21213/')
  const source = useLocalStorage<TikTokEventSource>('settings/tikfinity/event-source', 'tikfinity')
  const tiktokUsername = useLocalStorage('settings/tikfinity/tiktok-username', '')
  const includeLikes = useLocalStorage('settings/tikfinity/include-likes', false)
  const enabled = useLocalStorage('settings/tikfinity/enabled', false)
  const savedScores = useLocalStorage<TikFinityViewerScore[]>('settings/tikfinity/viewer-scores', [])
  const quizReward = useLocalStorage('settings/tikfinity/quiz-reward', 50)

  const snapshot = ref<TikFinityBridgeSnapshot>(idleSnapshot())
  const delivery = ref<TikFinityDeliverySnapshot>(idleDeliverySnapshot())
  const events = ref<TikFinityEvent[]>([])
  const records = ref<TikFinityRecord[]>([])
  const engagement = ref<TikFinityEngagementSnapshot>({ scores: savedScores.value })
  const errorMessage = ref('')
  const busy = ref(false)
  const isOwner = ref(false)
  const plugin = shallowRef<TikFinityAiriPlugin>()
  let activeSource: TikTokEventSource | undefined
  let directEventListener: ((event: unknown, payload: TikFinityEvent) => void) | undefined
  let directStatusListener: ((event: unknown, payload: unknown) => void) | undefined

  // Windows can resolve localhost to IPv6 while TikFinity listens on IPv4 only.
  if (/^ws:\/\/localhost:21213\/?$/i.test(endpoint.value.trim())) {
    endpoint.value = 'ws://127.0.0.1:21213/'
  }

  const { data, post } = useBroadcastChannel<RuntimeMessage, RuntimeMessage>({
    name: 'nabd-tikfinity-runtime-v2',
  })

  function stateSnapshot(): RuntimeState {
    return structuredClone({
      delivery: toRaw(delivery.value),
      engagement: toRaw(engagement.value),
      errorMessage: errorMessage.value,
      events: toRaw(events.value),
      records: toRaw(records.value),
      snapshot: toRaw(snapshot.value),
    })
  }

  function publishState(): void {
    if (isOwner.value)
      post({ kind: 'state', state: stateSnapshot() })
  }

  function applyState(state: RuntimeState): void {
    if (isOwner.value)
      return

    delivery.value = state.delivery
    engagement.value = state.engagement
    errorMessage.value = state.errorMessage
    events.value = state.events
    records.value = state.records
    snapshot.value = state.snapshot
    busy.value = state.snapshot.status === 'connecting'
  }

  function reportError(error: unknown): void {
    errorMessage.value = errorMessageFrom(error) ?? 'TikFinity connection failed.'
    busy.value = false
    publishState()
  }

  function removeDirectListeners(): void {
    if (directEventListener) {
      window.electron.ipcRenderer.removeListener('nabd:tiktok-direct:event', directEventListener)
      directEventListener = undefined
    }
    if (directStatusListener) {
      window.electron.ipcRenderer.removeListener('nabd:tiktok-direct:status', directStatusListener)
      directStatusListener = undefined
    }
  }

  function installDirectListeners(nextPlugin: TikFinityAiriPlugin): void {
    removeDirectListeners()
    directEventListener = (_event, payload) => {
      if (activeSource !== 'tiktok-direct' || plugin.value !== nextPlugin)
        return
      const raw = JSON.stringify(payload)
      records.value = [{ raw, recordedAt: payload.receivedAt }, ...records.value].slice(0, 30)
      snapshot.value = {
        ...snapshot.value,
        status: 'verified',
        rawMessageCount: snapshot.value.rawMessageCount + 1,
        eventCount: snapshot.value.eventCount + 1,
        sessionEventCount: snapshot.value.sessionEventCount + 1,
      }
      nextPlugin.ingestEvent(payload)
      publishState()
    }
    directStatusListener = (_event, payload) => {
      if (activeSource !== 'tiktok-direct' || !payload || typeof payload !== 'object')
        return
      const state = payload as { message?: unknown, status?: unknown }
      if (state.status === 'connecting') {
        snapshot.value = { ...snapshot.value, status: 'connecting' }
        busy.value = true
      }
      else if (state.status === 'socket-open' && snapshot.value.status !== 'verified') {
        snapshot.value = { ...snapshot.value, status: 'socket-open' }
        busy.value = false
      }
      else if (state.status === 'stopped') {
        snapshot.value = { ...snapshot.value, status: 'stopped' }
        busy.value = false
        if (typeof state.message === 'string')
          errorMessage.value = state.message
      }
      else if (state.status === 'error') {
        reportError(new Error(typeof state.message === 'string' ? state.message : 'تعذر الاتصال ببث TikTok المباشر.'))
        return
      }
      publishState()
    }
    window.electron.ipcRenderer.on('nabd:tiktok-direct:event', directEventListener)
    window.electron.ipcRenderer.on('nabd:tiktok-direct:status', directStatusListener)
  }

  async function connectLocally(): Promise<void> {
    const normalizedEndpoint = endpoint.value.trim()
    const normalizedUsername = tiktokUsername.value.trim().replace(/^@/, '')
    if (source.value === 'tikfinity' && !/^wss?:\/\//i.test(normalizedEndpoint)) {
      reportError(new Error('The TikFinity WebSocket address must start with ws:// or wss://.'))
      return
    }
    if (source.value === 'tiktok-direct' && !normalizedUsername) {
      reportError(new Error('أدخل اسم مستخدم حساب TikTok الذي يبث الآن.'))
      return
    }
    if (source.value === 'tikfinity')
      endpoint.value = normalizedEndpoint.endsWith('/') ? normalizedEndpoint : `${normalizedEndpoint}/`
    else
      tiktokUsername.value = normalizedUsername

    plugin.value?.stop()
    if (activeSource === 'tiktok-direct')
      void window.electron.ipcRenderer.invoke('nabd:tiktok-direct:disconnect')
    removeDirectListeners()
    activeSource = source.value
    errorMessage.value = ''
    busy.value = true
    snapshot.value = { ...snapshot.value, status: 'connecting', sessionEventCount: 0 }
    publishState()

    const nextPlugin = new TikFinityAiriPlugin({
      tikFinityEndpoint: endpoint.value,
      includeLikes: includeLikes.value,
      createAiriClient: () => ({
        connect: async () => serverChannelStore.ensureConnected(),
        sendOrThrow: event => serverChannelStore.send(event),
        close: () => {},
      }),
      onTikFinityEvent: (event) => {
        events.value = [event, ...events.value].slice(0, 30)
        publishState()
      },
      onTikFinityRecord: (record) => {
        records.value = [record, ...records.value].slice(0, 30)
        publishState()
      },
      onTikFinitySnapshot: activeSource === 'tikfinity'
        ? (value) => {
            snapshot.value = value
            busy.value = value.status === 'connecting'
            publishState()
          }
        : undefined,
      onDeliverySnapshot: (value) => {
        delivery.value = value
        publishState()
      },
      engagement: {
        initialScores: savedScores.value,
        onSnapshot: (value) => {
          engagement.value = value
          savedScores.value = value.scores
          publishState()
        },
      },
      onError: reportError,
    })

    plugin.value = nextPlugin
    if (activeSource === 'tiktok-direct') {
      installDirectListeners(nextPlugin)
      void nextPlugin.startExternal()
      void window.electron.ipcRenderer.invoke('nabd:tiktok-direct:connect', normalizedUsername).catch(reportError)
    }
    else {
      // The local TikFinity socket starts before the AIRI channel is ready.
      // Keep this task in the background so app startup cannot block live events.
      void nextPlugin.start()
    }
  }

  function disconnectLocally(): void {
    const currentPlugin = plugin.value
    currentPlugin?.cancelQuiz()
    currentPlugin?.cancelPoll()
    currentPlugin?.stop()
    plugin.value = undefined
    if (activeSource === 'tiktok-direct')
      void window.electron.ipcRenderer.invoke('nabd:tiktok-direct:disconnect')
    removeDirectListeners()
    activeSource = undefined
    delivery.value = { ...delivery.value, status: 'stopped', queuedMessageCount: 0 }
    snapshot.value = { ...snapshot.value, status: 'stopped' }
    busy.value = false
    publishState()
  }

  async function handleCommand(command: RuntimeCommand): Promise<void> {
    if (!isOwner.value)
      return

    switch (command.type) {
      case 'connect':
        endpoint.value = command.endpoint
        includeLikes.value = command.includeLikes
        source.value = command.source
        tiktokUsername.value = command.username
        await connectLocally()
        return
      case 'disconnect':
        disconnectLocally()
        return
      case 'request-state':
        publishState()
        return
      case 'clear-activity':
        events.value = []
        records.value = []
        publishState()
        return
      case 'clear-scores':
        plugin.value?.clearScores()
        if (!plugin.value) {
          savedScores.value = []
          engagement.value = { scores: [] }
          publishState()
        }
        return
      case 'start-quiz':
        plugin.value?.startQuiz(command.question, command.answers, command.rewardPoints)
        return
      case 'cancel-quiz':
        plugin.value?.cancelQuiz()
        return
      case 'start-poll':
        plugin.value?.startPoll(command.question, command.options)
        return
      case 'stop-poll':
        plugin.value?.stopPoll()
        return
      case 'cancel-poll':
        plugin.value?.cancelPoll()
    }
  }

  function sendCommand(command: RuntimeCommand): void {
    if (isOwner.value) {
      void handleCommand(command)
      return
    }
    post({ kind: 'command', command })
  }

  watch(data, (message) => {
    if (!message)
      return
    if (message.kind === 'state') {
      applyState(message.state)
      return
    }
    void handleCommand(message.command)
  })

  async function initializeOwner(): Promise<void> {
    isOwner.value = true
    if (enabled.value) {
      await connectLocally()
      return
    }
    publishState()
  }

  function initializeClient(): void {
    sendCommand({ type: 'request-state' })
  }

  function connect(): void {
    enabled.value = true
    errorMessage.value = ''
    busy.value = true
    snapshot.value = { ...snapshot.value, status: 'connecting' }
    sendCommand({
      type: 'connect',
      endpoint: endpoint.value,
      includeLikes: includeLikes.value,
      source: source.value,
      username: tiktokUsername.value,
    })
  }

  function disconnect(): void {
    enabled.value = false
    sendCommand({ type: 'disconnect' })
  }

  function clearActivity(): void {
    sendCommand({ type: 'clear-activity' })
  }

  function clearScores(): void {
    sendCommand({ type: 'clear-scores' })
  }

  function startQuiz(question: string, answers: string[], rewardPoints: number): void {
    sendCommand({ type: 'start-quiz', question, answers, rewardPoints })
  }

  function cancelQuiz(): void {
    sendCommand({ type: 'cancel-quiz' })
  }

  function startPoll(question: string, options: string[]): void {
    sendCommand({ type: 'start-poll', question, options })
  }

  function stopPoll(): void {
    sendCommand({ type: 'stop-poll' })
  }

  function disposeOwner(): void {
    if (!isOwner.value)
      return
    plugin.value?.stop()
    if (activeSource === 'tiktok-direct')
      void window.electron.ipcRenderer.invoke('nabd:tiktok-direct:disconnect')
    removeDirectListeners()
    plugin.value = undefined
    activeSource = undefined
    isOwner.value = false
  }

  return {
    endpoint,
    source,
    tiktokUsername,
    includeLikes,
    enabled,
    quizReward,
    snapshot,
    delivery,
    events,
    records,
    engagement,
    errorMessage,
    busy,
    initializeOwner,
    initializeClient,
    connect,
    disconnect,
    clearActivity,
    clearScores,
    startQuiz,
    cancelQuiz,
    startPoll,
    stopPoll,
    disposeOwner,
  }
})
