import type {
  TikFinityBridgeSnapshot,
  TikFinityEngagementSnapshot,
  TikFinityEvent,
  TikFinityRecord,
  TikFinityViewerScore,
} from '@proj-airi/airi-plugin-tikfinity'

import { errorMessageFrom } from '@moeru/std'
import { TikFinityAiriPlugin } from '@proj-airi/airi-plugin-tikfinity'
import { useModsServerChannelStore } from '@proj-airi/stage-ui/stores/mods/api/channel-server'
import { useBroadcastChannel, useLocalStorage } from '@vueuse/core'
import { defineStore } from 'pinia'
import { ref, shallowRef, toRaw, watch } from 'vue'

interface RuntimeState {
  engagement: TikFinityEngagementSnapshot
  errorMessage: string
  events: TikFinityEvent[]
  records: TikFinityRecord[]
  snapshot: TikFinityBridgeSnapshot
}

type RuntimeCommand
  = | { type: 'cancel-poll' }
    | { type: 'cancel-quiz' }
    | { type: 'clear-activity' }
    | { type: 'clear-scores' }
    | { type: 'connect', endpoint: string, includeLikes: boolean }
    | { type: 'disconnect' }
    | { type: 'request-state' }
    | { type: 'start-poll', question: string, options: string[] }
    | { type: 'start-quiz', question: string, answers: string[], rewardPoints: number }
    | { type: 'stop-poll' }

type RuntimeMessage
  = | { kind: 'command', command: RuntimeCommand }
    | { kind: 'state', state: RuntimeState }

function idleSnapshot(): TikFinityBridgeSnapshot {
  return {
    status: 'idle',
    rawMessageCount: 0,
    eventCount: 0,
    unknownMessageCount: 0,
    sessionEventCount: 0,
  }
}

/** Keeps the TikFinity connection in the main character window. */
export const useTikFinityRuntimeStore = defineStore('nabd-tikfinity-runtime', () => {
  const serverChannelStore = useModsServerChannelStore()
  const endpoint = useLocalStorage('settings/tikfinity/websocket-endpoint', 'ws://localhost:21213')
  const includeLikes = useLocalStorage('settings/tikfinity/include-likes', false)
  const enabled = useLocalStorage('settings/tikfinity/enabled', false)
  const savedScores = useLocalStorage<TikFinityViewerScore[]>('settings/tikfinity/viewer-scores', [])
  const quizReward = useLocalStorage('settings/tikfinity/quiz-reward', 50)

  const snapshot = ref<TikFinityBridgeSnapshot>(idleSnapshot())
  const events = ref<TikFinityEvent[]>([])
  const records = ref<TikFinityRecord[]>([])
  const engagement = ref<TikFinityEngagementSnapshot>({ scores: savedScores.value })
  const errorMessage = ref('')
  const busy = ref(false)
  const isOwner = ref(false)
  const plugin = shallowRef<TikFinityAiriPlugin>()

  const { data, post } = useBroadcastChannel<RuntimeMessage, RuntimeMessage>({
    name: 'nabd-tikfinity-runtime-v2',
  })

  function stateSnapshot(): RuntimeState {
    return structuredClone({
      engagement: toRaw(engagement.value),
      errorMessage: errorMessage.value,
      events: toRaw(events.value),
      records: toRaw(records.value),
      snapshot: toRaw(snapshot.value),
    })
  }

  function publishState(): void {
    if (isOwner.value)
      post({ kind: 'state', state: stateSnapshot() })
  }

  function applyState(state: RuntimeState): void {
    if (isOwner.value)
      return

    engagement.value = state.engagement
    errorMessage.value = state.errorMessage
    events.value = state.events
    records.value = state.records
    snapshot.value = state.snapshot
    busy.value = state.snapshot.status === 'connecting'
  }

  function reportError(error: unknown): void {
    errorMessage.value = errorMessageFrom(error) ?? 'TikFinity connection failed.'
    busy.value = false
    publishState()
  }

  async function connectLocally(): Promise<void> {
    const normalizedEndpoint = endpoint.value.trim()
    if (!/^wss?:\/\//i.test(normalizedEndpoint)) {
      reportError(new Error('The TikFinity WebSocket address must start with ws:// or wss://.'))
      return
    }

    plugin.value?.stop()
    errorMessage.value = ''
    busy.value = true
    snapshot.value = { ...snapshot.value, status: 'connecting' }
    publishState()

    const nextPlugin = new TikFinityAiriPlugin({
      tikFinityEndpoint: normalizedEndpoint,
      includeLikes: includeLikes.value,
      createAiriClient: () => ({
        connect: async () => serverChannelStore.ensureConnected(),
        sendOrThrow: event => serverChannelStore.send(event),
        close: () => {},
      }),
      onTikFinityEvent: (event) => {
        events.value = [event, ...events.value].slice(0, 30)
        publishState()
      },
      onTikFinityRecord: (record) => {
        records.value = [record, ...records.value].slice(0, 30)
        publishState()
      },
      onTikFinitySnapshot: (value) => {
        snapshot.value = value
        busy.value = value.status === 'connecting'
        publishState()
      },
      engagement: {
        initialScores: savedScores.value,
        onSnapshot: (value) => {
          engagement.value = value
          savedScores.value = value.scores
          publishState()
        },
      },
      onError: reportError,
    })

    plugin.value = nextPlugin
    try {
      await nextPlugin.start()
    }
    catch (error) {
      nextPlugin.stop()
      plugin.value = undefined
      reportError(error)
    }
    finally {
      busy.value = false
      publishState()
    }
  }

  function disconnectLocally(): void {
    const currentPlugin = plugin.value
    currentPlugin?.cancelQuiz()
    currentPlugin?.cancelPoll()
    currentPlugin?.stop()
    plugin.value = undefined
    if (!currentPlugin)
      snapshot.value = { ...snapshot.value, status: 'stopped' }
    busy.value = false
    publishState()
  }

  async function handleCommand(command: RuntimeCommand): Promise<void> {
    if (!isOwner.value)
      return

    switch (command.type) {
      case 'connect':
        endpoint.value = command.endpoint
        includeLikes.value = command.includeLikes
        await connectLocally()
        return
      case 'disconnect':
        disconnectLocally()
        return
      case 'request-state':
        publishState()
        return
      case 'clear-activity':
        events.value = []
        records.value = []
        publishState()
        return
      case 'clear-scores':
        plugin.value?.clearScores()
        if (!plugin.value) {
          savedScores.value = []
          engagement.value = { scores: [] }
          publishState()
        }
        return
      case 'start-quiz':
        plugin.value?.startQuiz(command.question, command.answers, command.rewardPoints)
        return
      case 'cancel-quiz':
        plugin.value?.cancelQuiz()
        return
      case 'start-poll':
        plugin.value?.startPoll(command.question, command.options)
        return
      case 'stop-poll':
        plugin.value?.stopPoll()
        return
      case 'cancel-poll':
        plugin.value?.cancelPoll()
    }
  }

  function sendCommand(command: RuntimeCommand): void {
    if (isOwner.value) {
      void handleCommand(command)
      return
    }
    post({ kind: 'command', command })
  }

  watch(data, (message) => {
    if (!message)
      return
    if (message.kind === 'state') {
      applyState(message.state)
      return
    }
    void handleCommand(message.command)
  })

  async function initializeOwner(): Promise<void> {
    isOwner.value = true
    if (enabled.value) {
      await connectLocally()
      return
    }
    publishState()
  }

  function initializeClient(): void {
    sendCommand({ type: 'request-state' })
  }

  function connect(): void {
    enabled.value = true
    errorMessage.value = ''
    busy.value = true
    snapshot.value = { ...snapshot.value, status: 'connecting' }
    sendCommand({ type: 'connect', endpoint: endpoint.value, includeLikes: includeLikes.value })
  }

  function disconnect(): void {
    enabled.value = false
    sendCommand({ type: 'disconnect' })
  }

  function clearActivity(): void {
    sendCommand({ type: 'clear-activity' })
  }

  function clearScores(): void {
    sendCommand({ type: 'clear-scores' })
  }

  function startQuiz(question: string, answers: string[], rewardPoints: number): void {
    sendCommand({ type: 'start-quiz', question, answers, rewardPoints })
  }

  function cancelQuiz(): void {
    sendCommand({ type: 'cancel-quiz' })
  }

  function startPoll(question: string, options: string[]): void {
    sendCommand({ type: 'start-poll', question, options })
  }

  function stopPoll(): void {
    sendCommand({ type: 'stop-poll' })
  }

  function disposeOwner(): void {
    if (!isOwner.value)
      return
    plugin.value?.stop()
    plugin.value = undefined
    isOwner.value = false
  }

  return {
    endpoint,
    includeLikes,
    enabled,
    quizReward,
    snapshot,
    events,
    records,
    engagement,
    errorMessage,
    busy,
    initializeOwner,
    initializeClient,
    connect,
    disconnect,
    clearActivity,
    clearScores,
    startQuiz,
    cancelQuiz,
    startPoll,
    stopPoll,
    disposeOwner,
  }
})
